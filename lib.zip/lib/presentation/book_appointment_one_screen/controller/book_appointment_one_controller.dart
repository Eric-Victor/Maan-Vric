import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/book_appointment_one_screen/models/book_appointment_one_model.dart';

/// A controller class for the BookAppointmentOneScreen.
///
/// This class manages the state of the BookAppointmentOneScreen, including the
/// current bookAppointmentOneModelObj
class BookAppointmentOneController extends GetxController {
  Rx<BookAppointmentOneModel> bookAppointmentOneModelObj =
      BookAppointmentOneModel().obs;

  Rx<String> radioGroup = "".obs;

  Rx<String> radioGroup1 = "".obs;

  Rx<String> radioGroup2 = "".obs;
}
