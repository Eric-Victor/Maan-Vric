import 'controller/pop_up_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class PopUpScreen extends GetWidget<PopUpController> {
  const PopUpScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: 343.h,
          padding: EdgeInsets.symmetric(
            horizontal: 12.h,
            vertical: 45.v,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgRectangle2120x120,
                height: 120.adaptSize,
                width: 120.adaptSize,
                radius: BorderRadius.circular(
                  60.h,
                ),
              ),
              SizedBox(height: 15.v),
              Container(
                width: 256.h,
                margin: EdgeInsets.only(
                  left: 30.h,
                  right: 32.h,
                ),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "msg_your_upcoming_virtual2".tr,
                        style: theme.textTheme.headlineSmall,
                      ),
                      TextSpan(
                        text: "msg_dr_jose_manavalan2".tr,
                        style: CustomTextStyles.headlineSmallPrimary,
                      ),
                      TextSpan(
                        text: "msg_has_been_scheduled".tr,
                        style: theme.textTheme.headlineSmall,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(height: 18.v),
              Text(
                "msg_22nd_wednesday".tr,
                style: theme.textTheme.titleSmall,
              ),
              SizedBox(height: 50.v),
              _buildTile(),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildTile() {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 10.h,
        vertical: 13.v,
      ),
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 36.v),
            child: CustomIconButton(
              height: 40.adaptSize,
              width: 40.adaptSize,
              padding: EdgeInsets.all(6.h),
              decoration: IconButtonStyleHelper.fillDeepPurple,
              child: CustomImageView(
                imagePath: ImageConstant.imgVideocam,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 9.h,
              top: 1.v,
            ),
            child: Column(
              children: [
                SizedBox(
                  width: 185.h,
                  child: Text(
                    "msg_test_your_device".tr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: CustomTextStyles.titleMediumBluegray90001.copyWith(
                      height: 1.38,
                    ),
                  ),
                ),
                SizedBox(height: 5.v),
                SizedBox(
                  width: 185.h,
                  child: Text(
                    "msg_make_sure_video".tr,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall!.copyWith(
                      height: 1.43,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgIconright,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.symmetric(vertical: 44.v),
          ),
        ],
      ),
    );
  }
}
