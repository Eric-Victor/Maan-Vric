import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/calendar_two_screen/models/calendar_two_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the CalendarTwoScreen.
///
/// This class manages the state of the CalendarTwoScreen, including the
/// current calendarTwoModelObj
class CalendarTwoController extends GetxController {
  TextEditingController doctorOneController = TextEditingController();

  TextEditingController doctorOneController1 = TextEditingController();

  Rx<CalendarTwoModel> calendarTwoModelObj = CalendarTwoModel().obs;

  @override
  void onClose() {
    super.onClose();
    doctorOneController.dispose();
    doctorOneController1.dispose();
  }
}
