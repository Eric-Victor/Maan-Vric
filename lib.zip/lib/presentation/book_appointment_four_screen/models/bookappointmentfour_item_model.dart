import '../../../core/app_export.dart';

/// This class is used in the [bookappointmentfour_item_widget] screen.
class BookappointmentfourItemModel {
  BookappointmentfourItemModel({
    this.emergency,
    this.newHealthConcern,
    this.findADoctor,
    this.id,
  }) {
    emergency = emergency ?? Rx(ImageConstant.imgEmergency);
    newHealthConcern = newHealthConcern ?? Rx("New Health Concern");
    findADoctor = findADoctor ?? Rx("Find a Doctor");
    id = id ?? Rx("");
  }

  Rx<String>? emergency;

  Rx<String>? newHealthConcern;

  Rx<String>? findADoctor;

  Rx<String>? id;
}
