import 'controller/homescreen_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:flutter/material.dart';

class HomescreenScreen extends GetWidget<HomescreenController> {
  const HomescreenScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 81.h, vertical: 336.v),
                        decoration: AppDecoration.fillPrimary.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder195),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: EdgeInsets.only(
                                          left: 13.h, right: 19.h),
                                      child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text("lbl_maanvric".tr,
                                                style: theme
                                                    .textTheme.displaySmall),
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgBeatingheart,
                                                height: 31.v,
                                                width: 33.h,
                                                margin: EdgeInsets.only(
                                                    left: 4.h,
                                                    top: 7.v,
                                                    bottom: 6.v))
                                          ]))),
                              SizedBox(height: 4.v),
                              Text("msg_your_personal_health".tr,
                                  style: theme.textTheme.bodyLarge),
                              SizedBox(height: 49.v)
                            ]))))));
  }
}
