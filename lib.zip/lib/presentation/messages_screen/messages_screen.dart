import 'controller/messages_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_leading_image.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_circleimage.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_image.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:flutter/material.dart';

class MessagesScreen extends GetWidget<MessagesController> {
  const MessagesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: SizedBox(
                              height: 741.v,
                              width: double.maxFinite,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.topCenter,
                                        child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 16.h,
                                                vertical: 24.v),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  _buildSenderMessageWith(),
                                                  SizedBox(height: 16.v),
                                                  _buildRecipientMessage(),
                                                  SizedBox(height: 26.v),
                                                  _buildFrame(),
                                                  SizedBox(height: 26.v),
                                                  _buildSenderMessageWith1(),
                                                  SizedBox(height: 23.v)
                                                ]))),
                                    _buildInputField()
                                  ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.only(top: 2.v, bottom: 1.v),
        decoration: AppDecoration.outlineGray,
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 3.v),
              CustomAppBar(
                  height: 72.v,
                  leadingWidth: 34.h,
                  leading: AppbarLeadingImage(
                      imagePath: ImageConstant.imgArrowLeftPrimary,
                      margin:
                          EdgeInsets.only(left: 16.h, top: 24.v, bottom: 23.v),
                      onTap: () {
                        onTapArrowLeft();
                      }),
                  centerTitle: true,
                  title: Column(children: [
                    AppbarTitleCircleimage(
                        imagePath: ImageConstant.imgRectangle210,
                        margin: EdgeInsets.symmetric(horizontal: 1.h)),
                    SizedBox(height: 5.v),
                    Row(children: [
                      AppbarSubtitleOne(text: "lbl_dr_jose".tr),
                      AppbarTitleImage(
                          imagePath: ImageConstant.imgArrowRightGray800,
                          margin:
                              EdgeInsets.only(left: 3.h, top: 5.v, bottom: 4.v))
                    ])
                  ]))
            ]));
  }

  /// Section Widget
  Widget _buildSenderMessageWith() {
    return Padding(
        padding: EdgeInsets.only(right: 10.h),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomImageView(
                imagePath: ImageConstant.imgRectangle211,
                height: 30.adaptSize,
                width: 30.adaptSize,
                radius: BorderRadius.circular(15.h),
                margin: EdgeInsets.only(top: 93.v)),
            Expanded(
                child: Padding(
                    padding: EdgeInsets.only(left: 11.h),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                              padding: EdgeInsets.only(left: 5.h, right: 61.h),
                              child: Row(children: [
                                Text("msg_dr_jose_manavalan".tr,
                                    style: CustomTextStyles
                                        .titleMediumBlack90001_1),
                                Padding(
                                    padding:
                                        EdgeInsets.only(left: 16.h, top: 3.v),
                                    child: Text("lbl_21_min_ago".tr,
                                        style: theme.textTheme.titleSmall))
                              ])),
                          SizedBox(height: 9.v),
                          _buildBubbleTail(
                              message: "msg_hey_rahul_following".tr)
                        ])))
          ]),
          SizedBox(height: 9.v),
          Padding(padding: EdgeInsets.only(left: 40.h), child: _buildRow())
        ]));
  }

  /// Section Widget
  Widget _buildRecipientMessage() {
    return Padding(
        padding: EdgeInsets.only(left: 10.h),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Expanded(
                child: Column(children: [
              Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                      padding: EdgeInsets.only(right: 4.h),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                                padding: EdgeInsets.only(top: 3.v),
                                child: Text("lbl_15_min_ago".tr,
                                    style: theme.textTheme.titleSmall)),
                            Padding(
                                padding: EdgeInsets.only(left: 16.h),
                                child: Text("lbl_rahul_menon".tr,
                                    style: CustomTextStyles
                                        .titleMediumBlack90001_1))
                          ]))),
              SizedBox(height: 9.v),
              SizedBox(
                  height: 72.v,
                  width: 306.h,
                  child: Stack(alignment: Alignment.bottomRight, children: [
                    Align(
                        alignment: Alignment.center,
                        child: Container(
                            margin: EdgeInsets.only(right: 4.h),
                            padding: EdgeInsets.symmetric(
                                horizontal: 12.h, vertical: 4.v),
                            decoration: AppDecoration.fillBlueA.copyWith(
                                borderRadius:
                                    BorderRadiusStyle.roundedBorder18),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 2.v),
                                  Container(
                                      width: 269.h,
                                      margin: EdgeInsets.only(right: 8.h),
                                      child: Text(
                                          "msg_thanks_for_the_reminder".tr,
                                          maxLines: 3,
                                          overflow: TextOverflow.ellipsis,
                                          style: CustomTextStyles
                                              .titleSmallOnPrimary
                                              .copyWith(height: 1.43)))
                                ]))),
                    CustomImageView(
                        imagePath: ImageConstant.imgTailBlueA200,
                        height: 20.v,
                        width: 16.h,
                        alignment: Alignment.bottomRight)
                  ]))
            ])),
            CustomImageView(
                imagePath: ImageConstant.imgRectangle28,
                height: 30.adaptSize,
                width: 30.adaptSize,
                radius: BorderRadius.circular(15.h),
                margin: EdgeInsets.only(left: 12.h, top: 73.v))
          ]),
          SizedBox(height: 10.v),
          Padding(padding: EdgeInsets.only(right: 40.h), child: _buildRow())
        ]));
  }

  /// Section Widget
  Widget _buildFrame() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 19.v),
              child: SizedBox(width: 128.h, child: Divider())),
          CustomOutlinedButton(
              height: 40.v,
              width: 62.h,
              text: "lbl_now".tr,
              margin: EdgeInsets.only(left: 10.h),
              buttonStyle: CustomButtonStyles.outlineBlueGray,
              buttonTextStyle: CustomTextStyles.titleSmallOnPrimaryContainer),
          Padding(
              padding: EdgeInsets.symmetric(vertical: 19.v),
              child: SizedBox(width: 138.h, child: Divider(indent: 10.h)))
        ]));
  }

  /// Section Widget
  Widget _buildSenderMessageWith1() {
    return Padding(
        padding: EdgeInsets.only(right: 10.h),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CustomImageView(
                imagePath: ImageConstant.imgRectangle211,
                height: 30.adaptSize,
                width: 30.adaptSize,
                radius: BorderRadius.circular(15.h),
                margin: EdgeInsets.only(top: 33.v)),
            Expanded(
                child: Padding(
                    padding: EdgeInsets.only(left: 11.h),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                              padding: EdgeInsets.only(left: 5.h),
                              child: Row(children: [
                                Text("msg_dr_jose_manavalan".tr,
                                    style: CustomTextStyles
                                        .titleMediumBlack90001_1),
                                Padding(
                                    padding:
                                        EdgeInsets.only(left: 16.h, top: 3.v),
                                    child: Text("lbl_2_min_ago".tr,
                                        style: theme.textTheme.titleSmall))
                              ])),
                          SizedBox(height: 9.v),
                          _buildBubbleTail(message: "msg_that_s_fine_hope".tr)
                        ])))
          ]),
          SizedBox(height: 9.v),
          Padding(
              padding: EdgeInsets.only(left: 40.h),
              child: Row(children: [
                Container(
                    height: 24.v,
                    width: 32.h,
                    padding:
                        EdgeInsets.symmetric(horizontal: 8.h, vertical: 4.v),
                    decoration: AppDecoration.fillBlueA.copyWith(
                        borderRadius: BorderRadiusStyle.circleBorder11),
                    child: CustomImageView(
                        imagePath: ImageConstant.imgMessageEmoji,
                        height: 16.adaptSize,
                        width: 16.adaptSize,
                        alignment: Alignment.center)),
                Container(
                    height: 24.v,
                    width: 32.h,
                    margin: EdgeInsets.only(left: 4.h),
                    padding:
                        EdgeInsets.symmetric(horizontal: 8.h, vertical: 4.v),
                    decoration: AppDecoration.fillGray5001.copyWith(
                        borderRadius: BorderRadiusStyle.circleBorder11),
                    child: CustomImageView(
                        imagePath: ImageConstant.imgMessageEmoji,
                        height: 16.adaptSize,
                        width: 16.adaptSize,
                        alignment: Alignment.center)),
                CustomImageView(
                    imagePath: ImageConstant.imgAddReaction,
                    height: 18.adaptSize,
                    width: 18.adaptSize,
                    margin: EdgeInsets.only(left: 4.h, top: 3.v, bottom: 3.v))
              ]))
        ]));
  }

  /// Section Widget
  Widget _buildInputField() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Container(
            padding: EdgeInsets.symmetric(horizontal: 25.h, vertical: 10.v),
            decoration: AppDecoration.outlineBlack900011,
            child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      width: 323.h,
                      margin: EdgeInsets.only(right: 15.h),
                      child: Text("msg_yes_i_am_a_lot".tr,
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.titleMediumBluegray70002
                              .copyWith(height: 1.50))),
                  SizedBox(height: 18.v),
                  Row(children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgAlternateEmail,
                        height: 20.adaptSize,
                        width: 20.adaptSize),
                    CustomImageView(
                        imagePath: ImageConstant.imgAttachFile,
                        height: 20.adaptSize,
                        width: 20.adaptSize,
                        margin: EdgeInsets.only(left: 10.h)),
                    CustomImageView(
                        imagePath: ImageConstant.imgImageBlueGray300,
                        height: 20.adaptSize,
                        width: 20.adaptSize,
                        margin: EdgeInsets.only(left: 10.h)),
                    CustomImageView(
                        imagePath: ImageConstant.imgSentimentSatisfiedAlt,
                        height: 20.adaptSize,
                        width: 20.adaptSize,
                        margin: EdgeInsets.only(left: 10.h)),
                    CustomImageView(
                        imagePath: ImageConstant.imgMoreVert,
                        height: 20.adaptSize,
                        width: 20.adaptSize,
                        margin: EdgeInsets.only(left: 10.h)),
                    Spacer(),
                    CustomImageView(
                        imagePath: ImageConstant.imgSend,
                        height: 20.adaptSize,
                        width: 20.adaptSize)
                  ]),
                  SizedBox(height: 41.v)
                ])));
  }

  /// Common widget
  Widget _buildRow() {
    return Row(mainAxisAlignment: MainAxisAlignment.end, children: [
      Container(
          height: 24.v,
          width: 32.h,
          padding: EdgeInsets.symmetric(horizontal: 8.h, vertical: 4.v),
          decoration: AppDecoration.fillGray5001
              .copyWith(borderRadius: BorderRadiusStyle.circleBorder11),
          child: CustomImageView(
              imagePath: ImageConstant.imgMessageEmoji,
              height: 16.adaptSize,
              width: 16.adaptSize,
              alignment: Alignment.center)),
      CustomImageView(
          imagePath: ImageConstant.imgAddReaction,
          height: 18.adaptSize,
          width: 18.adaptSize,
          margin: EdgeInsets.only(left: 4.h, top: 3.v, bottom: 3.v))
    ]);
  }

  /// Common widget
  Widget _buildBubbleTail({required String message}) {
    return SizedBox(
        height: 32.v,
        width: 307.h,
        child: Stack(alignment: Alignment.bottomLeft, children: [
          Align(
              alignment: Alignment.center,
              child: Container(
                  margin: EdgeInsets.only(left: 5.h),
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.h, vertical: 5.v),
                  decoration: AppDecoration.fillGray200
                      .copyWith(borderRadius: BorderRadiusStyle.circleBorder15),
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(height: 2.v),
                        Text(message,
                            style: CustomTextStyles.titleSmallBluegray80001
                                .copyWith(color: appTheme.blueGray80001))
                      ]))),
          CustomImageView(
              imagePath: ImageConstant.imgTail,
              height: 20.v,
              width: 16.h,
              alignment: Alignment.bottomLeft)
        ]));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
