import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/choose_doctor_screen/models/choose_doctor_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the ChooseDoctorScreen.
///
/// This class manages the state of the ChooseDoctorScreen, including the
/// current chooseDoctorModelObj
class ChooseDoctorController extends GetxController {
  TextEditingController searchController = TextEditingController();

  Rx<ChooseDoctorModel> chooseDoctorModelObj = ChooseDoctorModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  SelectionPopupModel? selectedDropDownValue2;

  @override
  void onClose() {
    super.onClose();
    searchController.dispose();
  }

  onSelected(dynamic value) {
    for (var element in chooseDoctorModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    chooseDoctorModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element in chooseDoctorModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    chooseDoctorModelObj.value.dropdownItemList1.refresh();
  }

  onSelected2(dynamic value) {
    for (var element in chooseDoctorModelObj.value.dropdownItemList2.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    chooseDoctorModelObj.value.dropdownItemList2.refresh();
  }
}
