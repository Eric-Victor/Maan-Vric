import 'controller/sign_up_two_tab_container_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/core/utils/validation_functions.dart';
import 'package:eric_s_application2/presentation/sign_up_two_page/sign_up_two_page.dart';
import 'package:eric_s_application2/widgets/custom_drop_down.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class SignUpTwoTabContainerScreen
    extends GetWidget<SignUpTwoTabContainerController> {
  SignUpTwoTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 627.v,
                    width: double.maxFinite,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        _buildLogIn(),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16.h),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _buildInputWithLabel(),
                                SizedBox(height: 21.v),
                                _buildInputWithLabel1(),
                                SizedBox(height: 20.v),
                                _buildInputWithLabel2(),
                                SizedBox(height: 19.v),
                                _buildInputWithLabel3(),
                                SizedBox(height: 21.v),
                                _buildInputWithLabel4(),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildTabBarView(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildLogIn() {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 16.h,
          vertical: 48.v,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "msg_basic_information".tr,
              style: theme.textTheme.headlineSmall,
            ),
            SizedBox(height: 11.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 306.h,
                margin: EdgeInsets.only(right: 52.h),
                child: Text(
                  "msg_please_tell_us_some".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleMedium!.copyWith(
                    height: 1.50,
                  ),
                ),
              ),
            ),
            SizedBox(height: 9.v),
            CustomImageView(
              imagePath: ImageConstant.imgProgressbar,
              height: 3.v,
              width: 358.h,
              radius: BorderRadius.circular(
                1.h,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_first_name".tr,
          style: CustomTextStyles.titleSmallBluegray80001,
        ),
        SizedBox(height: 6.v),
        CustomTextFormField(
          controller: controller.firstNameController,
          hintText: "lbl_first_name".tr,
          prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
              imagePath: ImageConstant.imgAccountcircle,
              height: 20.adaptSize,
              width: 20.adaptSize,
            ),
          ),
          prefixConstraints: BoxConstraints(
            maxHeight: 56.v,
          ),
          validator: (value) {
            if (!isText(value)) {
              return "err_msg_please_enter_valid_text".tr;
            }
            return null;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_last_name".tr,
          style: CustomTextStyles.titleSmallBluegray80001,
        ),
        SizedBox(height: 6.v),
        CustomTextFormField(
          controller: controller.lastNameController,
          hintText: "lbl_last_name".tr,
          textInputAction: TextInputAction.done,
          prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
              imagePath: ImageConstant.imgAccountcircle,
              height: 20.adaptSize,
              width: 20.adaptSize,
            ),
          ),
          prefixConstraints: BoxConstraints(
            maxHeight: 56.v,
          ),
          validator: (value) {
            if (!isText(value)) {
              return "err_msg_please_enter_valid_text".tr;
            }
            return null;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel2() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_date_of_birth".tr,
          style: CustomTextStyles.titleSmallBluegray80001,
        ),
        SizedBox(height: 6.v),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CustomDropDown(
              width: 140.h,
              icon: Container(
                margin: EdgeInsets.fromLTRB(30.h, 16.v, 14.h, 16.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgArrowdropup,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                ),
              ),
              hintText: "lbl_month".tr,
              hintStyle: theme.textTheme.titleMedium!,
              items: controller
                  .signUpTwoTabContainerModelObj.value.dropdownItemList!.value,
              contentPadding: EdgeInsets.only(
                left: 14.h,
                top: 17.v,
                bottom: 17.v,
              ),
              borderDecoration: DropDownStyleHelper.outlinePrimaryContainer,
              onChanged: (value) {
                controller.onSelected(value);
              },
            ),
            CustomOutlinedButton(
              height: 56.v,
              width: 103.h,
              text: "lbl_day".tr,
              buttonStyle: CustomButtonStyles.outlinePrimaryContainer,
              buttonTextStyle: theme.textTheme.titleMedium!,
            ),
            Container(
              width: 103.h,
              padding: EdgeInsets.symmetric(
                horizontal: 27.h,
                vertical: 16.v,
              ),
              decoration: AppDecoration.outlinePrimaryContainer.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder8,
              ),
              child: Text(
                "lbl_year".tr,
                style: theme.textTheme.titleMedium,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel3() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_phone_number".tr,
          style: CustomTextStyles.titleSmallPoppinsBluegray80001,
        ),
        SizedBox(height: 5.v),
        Container(
          decoration: AppDecoration.outlinePrimaryContainer.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder8,
          ),
          child: Row(
            children: [
              CustomDropDown(
                width: 73.h,
                icon: Container(
                  margin: EdgeInsets.only(right: 12.h),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgArrowdown,
                    height: 20.adaptSize,
                    width: 20.adaptSize,
                  ),
                ),
                hintText: "lbl_ind".tr,
                items: controller.signUpTwoTabContainerModelObj.value
                    .dropdownItemList1!.value,
                contentPadding: EdgeInsets.only(
                  left: 14.h,
                  top: 16.v,
                  bottom: 16.v,
                ),
                borderDecoration: DropDownStyleHelper.fillGray,
                fillColor: appTheme.gray100,
                onChanged: (value) {
                  controller.onSelected1(value);
                },
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 10.h,
                  top: 16.v,
                  bottom: 17.v,
                ),
                child: Text(
                  "lbl_91".tr,
                  style: theme.textTheme.titleMedium,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel4() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_gender".tr,
          style: CustomTextStyles.titleSmallBluegray80001,
        ),
        SizedBox(height: 6.v),
        Container(
          height: 32.v,
          width: 358.h,
          decoration: BoxDecoration(
            color: appTheme.gray6001e,
            borderRadius: BorderRadius.circular(
              8.h,
            ),
          ),
          child: TabBar(
            controller: controller.tabviewController,
            labelPadding: EdgeInsets.zero,
            labelColor: appTheme.black90001,
            labelStyle: TextStyle(
              fontSize: 16.fSize,
              fontFamily: 'GT Walsheim Pro',
              fontWeight: FontWeight.w700,
            ),
            unselectedLabelColor: appTheme.blueGray70002,
            unselectedLabelStyle: TextStyle(
              fontSize: 16.fSize,
              fontFamily: 'GT Walsheim Pro',
              fontWeight: FontWeight.w700,
            ),
            indicatorPadding: EdgeInsets.all(
              2.0.h,
            ),
            indicator: BoxDecoration(
              color: theme.colorScheme.onPrimary.withOpacity(1),
              borderRadius: BorderRadius.circular(
                6.h,
              ),
              border: Border.all(
                color: appTheme.black90001.withOpacity(0.04),
                width: 1.h,
                strokeAlign: strokeAlignOutside,
              ),
              boxShadow: [
                BoxShadow(
                  color: appTheme.black90001.withOpacity(0.04),
                  spreadRadius: 2.h,
                  blurRadius: 2.h,
                  offset: Offset(
                    0,
                    3,
                  ),
                ),
              ],
            ),
            tabs: [
              Tab(
                child: Text(
                  "lbl_male".tr,
                ),
              ),
              Tab(
                child: Text(
                  "lbl_female".tr,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildTabBarView() {
    return SizedBox(
      height: 237.v,
      child: TabBarView(
        controller: controller.tabviewController,
        children: [
          SignUpTwoPage(),
          SignUpTwoPage(),
        ],
      ),
    );
  }
}
