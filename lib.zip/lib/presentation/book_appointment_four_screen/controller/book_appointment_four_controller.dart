import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/book_appointment_four_screen/models/book_appointment_four_model.dart';

/// A controller class for the BookAppointmentFourScreen.
///
/// This class manages the state of the BookAppointmentFourScreen, including the
/// current bookAppointmentFourModelObj
class BookAppointmentFourController extends GetxController {
  Rx<BookAppointmentFourModel> bookAppointmentFourModelObj =
      BookAppointmentFourModel().obs;
}
