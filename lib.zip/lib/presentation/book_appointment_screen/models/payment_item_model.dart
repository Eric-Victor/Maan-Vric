import '../../../core/app_export.dart';

/// This class is used in the [payment_item_widget] screen.
class PaymentItemModel {
  Rx<String>? inputField = Rx("Pay");

  Rx<bool>? isSelected = Rx(false);
}
