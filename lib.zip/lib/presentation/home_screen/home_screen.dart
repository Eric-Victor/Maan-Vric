import 'controller/home_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container_page/search_container_page.dart';
import 'package:eric_s_application2/widgets/custom_bottom_bar.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class HomeScreen extends GetWidget<HomeController> {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: mediaQueryData.size.width,
                child: SingleChildScrollView(
                    child: Column(children: [
                  Container(
                      height: 16.v,
                      width: double.maxFinite,
                      decoration: BoxDecoration()),
                  Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 16.h, vertical: 32.v),
                      decoration: AppDecoration.fillOnPrimary,
                      child: Column(children: [
                        _buildHeader(),
                        SizedBox(height: 15.v),
                        Divider(),
                        SizedBox(height: 21.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("msg_upcoming_appointments".tr,
                                style: CustomTextStyles.titleLargePrimary)),
                        SizedBox(height: 9.v),
                        _buildTile(),
                        SizedBox(height: 16.v),
                        Divider(),
                        SizedBox(height: 35.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("msg_for_general_needs".tr,
                                style: CustomTextStyles.titleMediumGray900)),
                        SizedBox(height: 8.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                width: 314.h,
                                margin: EdgeInsets.only(right: 43.h),
                                child: Text("msg_get_medical_advice".tr,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: theme.textTheme.titleMedium!
                                        .copyWith(height: 1.50)))),
                        SizedBox(height: 31.v),
                        _buildTile1(),
                        SizedBox(height: 24.v),
                        _buildTile2(),
                        SizedBox(height: 24.v),
                        _buildTile3(),
                        SizedBox(height: 24.v),
                        _buildTile4(),
                        SizedBox(height: 18.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                                padding: EdgeInsets.only(left: 10.h),
                                child: Row(children: [
                                  Padding(
                                      padding:
                                          EdgeInsets.symmetric(vertical: 3.v),
                                      child: Text("msg_see_more_actions".tr,
                                          style: CustomTextStyles
                                              .titleSmallPrimary)),
                                  CustomImageView(
                                      imagePath:
                                          ImageConstant.imgIconrightPrimary,
                                      height: 24.adaptSize,
                                      width: 24.adaptSize,
                                      margin: EdgeInsets.only(left: 10.h))
                                ]))),
                        SizedBox(height: 46.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("msg_for_specific_needs".tr,
                                style: CustomTextStyles.titleMediumGray900)),
                        SizedBox(height: 6.v),
                        Container(
                            width: 351.h,
                            margin: EdgeInsets.only(right: 6.h),
                            child: Text("msg_our_primary_care".tr,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleMedium!
                                    .copyWith(height: 1.50))),
                        SizedBox(height: 30.v),
                        _buildTile5(),
                        SizedBox(height: 24.v),
                        _buildTile6(),
                        SizedBox(height: 24.v),
                        _buildTile7(),
                        SizedBox(height: 24.v),
                        _buildTile8(),
                        SizedBox(height: 24.v)
                      ]))
                ]))),
            bottomNavigationBar: _buildBottomBar()));
  }

  /// Section Widget
  Widget _buildHeader() {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
              padding: EdgeInsets.only(top: 1.v),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("lbl_hi_rahul".tr, style: theme.textTheme.titleLarge),
                    SizedBox(height: 7.v),
                    Text("msg_what_do_you_want".tr,
                        style: theme.textTheme.titleMedium)
                  ])),
          Padding(
              padding: EdgeInsets.only(bottom: 18.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(8.h),
                  decoration: IconButtonStyleHelper.outlineBlueGray,
                  child: CustomImageView(
                      imagePath: ImageConstant.imgNotifications)))
        ]);
  }

  /// Section Widget
  Widget _buildTile() {
    return GestureDetector(
        onTap: () {
          onTapTile();
        },
        child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
            decoration: AppDecoration.fillOnPrimary
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Padding(
                  padding: EdgeInsets.symmetric(vertical: 14.v),
                  child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(6.h),
                      decoration: IconButtonStyleHelper.fillTeal,
                      child: CustomImageView(
                          imagePath: ImageConstant.imgCalendarMonth))),
              Padding(
                  padding: EdgeInsets.only(left: 10.h, top: 1.v),
                  child: Column(children: [
                    SizedBox(
                        width: 188.h,
                        child: Text("msg_you_currently_have".tr,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: CustomTextStyles.titleMediumBluegray90001
                                .copyWith(height: 1.38))),
                    SizedBox(height: 4.v),
                    Text("msg_book_an_appointment".tr,
                        style: theme.textTheme.titleSmall)
                  ])),
              Spacer(),
              CustomImageView(
                  imagePath: ImageConstant.imgIconright,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                  margin: EdgeInsets.symmetric(vertical: 22.v))
            ])));
  }

  /// Section Widget
  Widget _buildTile1() {
    return GestureDetector(
        onTap: () {
          onTapTile1();
        },
        child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
            decoration: AppDecoration.outlineBlueGrayF
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Padding(
                  padding: EdgeInsets.symmetric(vertical: 13.v),
                  child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(6.h),
                      child: CustomImageView(imagePath: ImageConstant.imgDuo))),
              Padding(
                  padding: EdgeInsets.only(left: 10.h),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("msg_talk_to_a_doctor".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 5.v),
                        SizedBox(
                            width: 226.h,
                            child: Text("msg_get_medical_advice2".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ])),
              Spacer(),
              CustomImageView(
                  imagePath: ImageConstant.imgIconright,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                  margin: EdgeInsets.symmetric(vertical: 21.v))
            ])));
  }

  /// Section Widget
  Widget _buildTile2() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 13.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillDeepOrange,
                  child: CustomImageView(imagePath: ImageConstant.imgIcon))),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(left: 10.h, top: 1.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("msg_request_urgent_care".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 3.v),
                        SizedBox(
                            width: 251.h,
                            child: Text("msg_chat_by_video_with".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ]))),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(left: 12.h, top: 21.v, bottom: 21.v))
        ]));
  }

  /// Section Widget
  Widget _buildTile3() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 14.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 14.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillTealTL20,
                  child:
                      CustomImageView(imagePath: ImageConstant.imgVaccines))),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(left: 10.h, top: 3.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("msg_locate_a_pharmacy".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 3.v),
                        SizedBox(
                            width: 244.h,
                            child: Text("msg_locate_a_pharmacy2".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ]))),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(left: 19.h, top: 22.v, bottom: 22.v))
        ]));
  }

  /// Section Widget
  Widget _buildTile4() {
    return GestureDetector(
        onTap: () {
          onTapTile2();
        },
        child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 14.v),
            decoration: AppDecoration.outlineBlueGrayF
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Padding(
                  padding: EdgeInsets.symmetric(vertical: 24.v),
                  child: CustomIconButton(
                      height: 40.adaptSize,
                      width: 40.adaptSize,
                      padding: EdgeInsets.all(6.h),
                      decoration: IconButtonStyleHelper.fillDeepPurple,
                      child:
                          CustomImageView(imagePath: ImageConstant.imgEvent))),
              Padding(
                  padding: EdgeInsets.only(left: 10.h, top: 2.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("msg_book_an_appointment2".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 4.v),
                        SizedBox(
                            width: 229.h,
                            child: Text("msg_choos_a_primary".tr,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ])),
              Spacer(),
              CustomImageView(
                  imagePath: ImageConstant.imgIconright,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                  margin: EdgeInsets.symmetric(vertical: 32.v))
            ])));
  }

  /// Section Widget
  Widget _buildTile5() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 14.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillPurple,
                  child: CustomImageView(imagePath: ImageConstant.imgFemale))),
          Padding(
              padding: EdgeInsets.only(top: 1.v),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("lbl_women_s_health".tr,
                        style: CustomTextStyles.titleMediumBluegray90001),
                    SizedBox(height: 5.v),
                    SizedBox(
                        width: 249.h,
                        child: Text("msg_uti_birth_control".tr,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleSmall!
                                .copyWith(height: 1.43)))
                  ])),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.symmetric(vertical: 22.v))
        ]));
  }

  /// Section Widget
  Widget _buildTile6() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 13.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 15.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillYellow,
                  child:
                      CustomImageView(imagePath: ImageConstant.imgPhBabyFill))),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(left: 10.h, top: 1.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("msg_children_s_health".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 5.v),
                        SizedBox(
                            width: 254.h,
                            child: Text("msg_cold_flu_symptoms".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ]))),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(left: 10.h, top: 23.v, bottom: 23.v))
        ]));
  }

  /// Section Widget
  Widget _buildTile7() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 23.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  child: CustomImageView(imagePath: ImageConstant.imgMale))),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(left: 10.h),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("lbl_men_s_health".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 5.v),
                        SizedBox(
                            width: 239.h,
                            child: Text("msg_sti_symptoons_erection".tr,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ]))),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(left: 24.h, top: 31.v, bottom: 31.v))
        ]));
  }

  /// Section Widget
  Widget _buildTile8() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
        decoration: AppDecoration.outlineBlueGrayF
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 23.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillIndigo,
                  child: CustomImageView(
                      imagePath: ImageConstant.imgElderlyWoman))),
          Padding(
              padding: EdgeInsets.only(left: 10.h),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("lbl_senior_health".tr,
                        style: CustomTextStyles.titleMediumBluegray90001),
                    SizedBox(height: 5.v),
                    SizedBox(
                        width: 217.h,
                        child: Text("msg_muscle_or_joint".tr,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleSmall!
                                .copyWith(height: 1.43)))
                  ])),
          Spacer(),
          CustomImageView(
              imagePath: ImageConstant.imgIconright,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.symmetric(vertical: 31.v))
        ]));
  }

  /// Section Widget
  Widget _buildBottomBar() {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Get.toNamed(getCurrentRoute(type), id: 1);
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.searchContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Message:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.searchContainerPage:
        return SearchContainerPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapTile() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapTile1() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapTile2() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }
}
