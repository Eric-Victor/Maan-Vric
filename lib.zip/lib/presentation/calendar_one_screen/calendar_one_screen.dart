import 'controller/calendar_one_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button_one.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_elevated_button.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_pin_code_text_field.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class CalendarOneScreen extends GetWidget<CalendarOneController> {
  const CalendarOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Container(
                              height: 749.v,
                              width: double.maxFinite,
                              margin: EdgeInsets.only(bottom: 5.v),
                              padding: EdgeInsets.symmetric(vertical: 24.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.topCenter,
                                        child: Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 15.h),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  SizedBox(
                                                      width: 358.h,
                                                      child: Text(
                                                          "msg_confirm_a_date_and"
                                                              .tr,
                                                          maxLines: 3,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 9.v),
                                                  _buildOtpView(),
                                                  SizedBox(height: 40.v),
                                                  Text("lbl_doctor".tr,
                                                      style: theme.textTheme
                                                          .titleSmall),
                                                  SizedBox(height: 16.v),
                                                  _buildDoctor1(),
                                                  SizedBox(height: 16.v),
                                                  Divider(),
                                                  SizedBox(height: 32.v),
                                                  Text("lbl_service".tr,
                                                      style: theme.textTheme
                                                          .titleSmall),
                                                  SizedBox(height: 17.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 48.h),
                                                      child: Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                        top: 11
                                                                            .v,
                                                                        bottom: 14
                                                                            .v),
                                                                child: Text(
                                                                    "lbl_medical_officer"
                                                                        .tr,
                                                                    style: CustomTextStyles
                                                                        .titleMediumGray900_1)),
                                                            Container(
                                                                height: 1.v,
                                                                width: 20.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 10
                                                                            .h,
                                                                        top: 22
                                                                            .v,
                                                                        bottom: 24
                                                                            .v),
                                                                decoration: BoxDecoration(
                                                                    color: appTheme
                                                                        .gray900)),
                                                            Container(
                                                                width: 148.h,
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        left: 9
                                                                            .h),
                                                                child: Text(
                                                                    "msg_video_consultation"
                                                                        .tr,
                                                                    maxLines: 2,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    style: CustomTextStyles
                                                                        .titleMediumBluegray70002
                                                                        .copyWith(
                                                                            height:
                                                                                1.50)))
                                                          ])),
                                                  SizedBox(height: 31.v),
                                                  Text("lbl_date_time".tr,
                                                      style: theme.textTheme
                                                          .titleSmall),
                                                  SizedBox(height: 8.v),
                                                  _buildFrame(),
                                                  SizedBox(height: 32.v),
                                                  Divider(),
                                                  SizedBox(height: 24.v),
                                                  Text("lbl_note".tr,
                                                      style: theme.textTheme
                                                          .titleSmall),
                                                  SizedBox(height: 8.v),
                                                  _buildVuesaxlineartextalignjustifyri(),
                                                  SizedBox(height: 24.v),
                                                  Text("lbl_attachments".tr,
                                                      style: theme.textTheme
                                                          .titleSmall),
                                                  SizedBox(height: 8.v),
                                                  _buildAdd()
                                                ]))),
                                    _buildInputField()
                                  ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 16.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 4.v),
              CustomAppBar(
                  title: Padding(
                      padding: EdgeInsets.only(left: 8.h),
                      child: Row(children: [
                        AppbarTitleButtonOne(
                            margin: EdgeInsets.only(bottom: 3.v),
                            onTap: () {
                              onTapBack();
                            }),
                        AppbarTitle(
                            text: "msg_book_an_appointment2".tr,
                            margin: EdgeInsets.only(left: 14.h))
                      ])))
            ]));
  }

  /// Section Widget
  Widget _buildOtpView() {
    return Obx(() => CustomPinCodeTextField(
        context: Get.context!,
        controller: controller.otpController.value,
        onChanged: (value) {}));
  }

  /// Section Widget
  Widget _buildDoctor1() {
    return Container(
        decoration: AppDecoration.fillOnPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
              height: 40.adaptSize,
              width: 40.adaptSize,
              margin: EdgeInsets.only(bottom: 6.v),
              child: Stack(alignment: Alignment.bottomRight, children: [
                CustomImageView(
                    imagePath: ImageConstant.imgRectangle27,
                    height: 40.adaptSize,
                    width: 40.adaptSize,
                    radius: BorderRadius.circular(20.h),
                    alignment: Alignment.center),
                Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                        height: 10.adaptSize,
                        width: 10.adaptSize,
                        decoration: BoxDecoration(
                            color: appTheme.greenA700,
                            borderRadius: BorderRadius.circular(5.h),
                            border: Border.all(
                                color: appTheme.gray100,
                                width: 1.h,
                                strokeAlign: strokeAlignOutside))))
              ])),
          Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("msg_dr_jose_manavalan".tr,
                        style: CustomTextStyles.titleMediumBluegray90001),
                    SizedBox(height: 6.v),
                    Text("msg_mbbs_md_general".tr,
                        style: theme.textTheme.titleSmall)
                  ]))
        ]));
  }

  /// Section Widget
  Widget _buildNdWedJune2022() {
    return CustomElevatedButton(
        width: 190.h, text: "msg_22nd_wed_june_2022".tr);
  }

  /// Section Widget
  Widget _buildFrame() {
    return Padding(
        padding: EdgeInsets.only(right: 20.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          _buildNdWedJune2022(),
          SizedBox(
              height: 36.v,
              child: VerticalDivider(
                  width: 1.h,
                  thickness: 1.v,
                  color: theme.colorScheme.primaryContainer,
                  indent: 8.h,
                  endIndent: 8.h)),
          Container(
              width: 93.h,
              padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 6.v),
              decoration: AppDecoration.fillGrayE
                  .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
              child: Text("lbl_12_00_pm".tr,
                  style: CustomTextStyles.titleMediumBlack90001_1))
        ]));
  }

  /// Section Widget
  Widget _buildVuesaxlineartextalignjustifyri() {
    return CustomTextFormField(
        controller: controller.vuesaxlineartextalignjustifyriController,
        hintText: "msg_type_your_complaints".tr,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(30.h, 30.v, 5.h, 5.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgVuesaxLinearTextalignjustifyright,
                height: 18.adaptSize,
                width: 18.adaptSize)),
        suffixConstraints: BoxConstraints(maxHeight: 80.v),
        maxLines: 3,
        contentPadding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 11.v),
        borderDecoration: TextFormFieldStyleHelper.outlinePrimaryContainerTL6);
  }

  /// Section Widget
  Widget _buildAdd() {
    return CustomTextFormField(
        width: 151.h,
        controller: controller.addController,
        hintText: "lbl_add_attachments".tr,
        hintStyle: CustomTextStyles.titleSmallPrimary,
        textInputAction: TextInputAction.done,
        prefix: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 24.v),
        contentPadding: EdgeInsets.symmetric(vertical: 2.v));
  }

  /// Section Widget
  Widget _buildHeathProfile() {
    return CustomOutlinedButton(
        height: 43.v,
        text: "lbl_heath_profile".tr,
        rightIcon: Container(
            margin: EdgeInsets.only(left: 8.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgArrowright,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
        onPressed: () {
          onTapHeathProfile();
        });
  }

  /// Section Widget
  Widget _buildInputField() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Container(
            margin: EdgeInsets.only(bottom: 5.v),
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            decoration: AppDecoration.outlineBlack90001,
            child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [SizedBox(height: 7.v), _buildHeathProfile()])));
  }

  /// Navigates to the chooseDoctorScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.chooseDoctorScreen,
    );
  }

  /// Navigates to the bookAppointmentThreeScreen when the action is triggered.
  onTapHeathProfile() {
    Get.toNamed(
      AppRoutes.bookAppointmentThreeScreen,
    );
  }
}
