import '../controller/search_container1_controller.dart';
import 'package:get/get.dart';

/// A binding class for the SearchContainer1Screen.
///
/// This class ensures that the SearchContainer1Controller is created when the
/// SearchContainer1Screen is first loaded.
class SearchContainer1Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SearchContainer1Controller());
  }
}
