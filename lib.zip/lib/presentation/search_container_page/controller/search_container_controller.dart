import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container_page/models/search_container_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SearchContainerPage.
///
/// This class manages the state of the SearchContainerPage, including the
/// current searchContainerModelObj
class SearchContainerController extends GetxController {
  SearchContainerController(this.searchContainerModelObj);

  TextEditingController searchController = TextEditingController();

  Rx<SearchContainerModel> searchContainerModelObj;

  @override
  void onClose() {
    super.onClose();
    searchController.dispose();
  }
}
