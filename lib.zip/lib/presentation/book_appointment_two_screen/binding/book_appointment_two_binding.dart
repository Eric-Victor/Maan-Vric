import '../controller/book_appointment_two_controller.dart';
import 'package:get/get.dart';

/// A binding class for the BookAppointmentTwoScreen.
///
/// This class ensures that the BookAppointmentTwoController is created when the
/// BookAppointmentTwoScreen is first loaded.
class BookAppointmentTwoBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BookAppointmentTwoController());
  }
}
