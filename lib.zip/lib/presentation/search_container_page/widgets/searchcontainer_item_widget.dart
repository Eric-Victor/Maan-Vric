import '../controller/search_container_controller.dart';
import '../models/searchcontainer_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class SearchcontainerItemWidget extends StatelessWidget {
  SearchcontainerItemWidget(
    this.searchcontainerItemModelObj, {
    Key? key,
    this.onTapComponent,
  }) : super(
          key: key,
        );

  SearchcontainerItemModel searchcontainerItemModelObj;

  var controller = Get.find<SearchContainerController>();

  VoidCallback? onTapComponent;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapComponent!.call();
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 16.h,
          vertical: 13.v,
        ),
        decoration: AppDecoration.fillPurple50,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Obx(
              () => CustomIconButton(
                height: 47.adaptSize,
                width: 47.adaptSize,
                padding: EdgeInsets.all(10.h),
                decoration: IconButtonStyleHelper.fillDeepPurpleTL23,
                child: CustomImageView(
                  imagePath: searchcontainerItemModelObj.event!.value,
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(
              width: 99.h,
              child: Obx(
                () => Text(
                  searchcontainerItemModelObj.bookAnAppointment!.value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleMediumGray900_1.copyWith(
                    height: 1.50,
                  ),
                ),
              ),
            ),
            SizedBox(height: 21.v),
            Obx(
              () => Text(
                searchcontainerItemModelObj.findADoctor!.value,
                style: CustomTextStyles.labelLargeBluegray70002,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
