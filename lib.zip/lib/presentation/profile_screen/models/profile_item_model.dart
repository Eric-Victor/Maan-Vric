import '../../../core/app_export.dart';

/// This class is used in the [profile_item_widget] screen.
class ProfileItemModel {
  ProfileItemModel({
    this.settings,
    this.settings1,
    this.description,
    this.id,
  }) {
    settings = settings ?? Rx(ImageConstant.imgSettings);
    settings1 = settings1 ?? Rx("Settings");
    description = description ?? Rx("Configure tyour account your way");
    id = id ?? Rx("");
  }

  Rx<String>? settings;

  Rx<String>? settings1;

  Rx<String>? description;

  Rx<String>? id;
}
