import 'controller/book_appointment_two_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button_one.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_pin_code_text_field.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class BookAppointmentTwoScreen extends GetWidget<BookAppointmentTwoController> {
  const BookAppointmentTwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Container(
                              padding: EdgeInsets.symmetric(vertical: 24.v),
                              child: Column(children: [
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Container(
                                        width: 318.h,
                                        margin: EdgeInsets.only(
                                            left: 16.h, right: 56.h),
                                        child: Text(
                                            "msg_make_sure_all_details".tr,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: theme.textTheme.titleMedium!
                                                .copyWith(height: 1.50)))),
                                SizedBox(height: 9.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 16.h),
                                    child: Obx(() => CustomPinCodeTextField(
                                        context: Get.context!,
                                        controller:
                                            controller.otpController.value,
                                        onChanged: (value) {}))),
                                SizedBox(height: 40.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 16.h),
                                    child: CustomTextFormField(
                                        controller: controller.reasonController,
                                        hintText: "msg_new_health_concern".tr,
                                        textInputAction: TextInputAction.done,
                                        prefix: Container(
                                            margin: EdgeInsets.fromLTRB(
                                                26.h, 16.v, 18.h, 16.v),
                                            child: CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgEmergency,
                                                height: 20.adaptSize,
                                                width: 20.adaptSize)),
                                        prefixConstraints:
                                            BoxConstraints(maxHeight: 52.v),
                                        borderDecoration:
                                            TextFormFieldStyleHelper
                                                .fillDeepOrange,
                                        fillColor: appTheme.deepOrange50)),
                                SizedBox(height: 36.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("msg_how_long_have_you".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 21.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_3_days".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 17.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 37.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("msg_list_of_symptoms".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 10.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping:
                                            "msg_diificulty_sleeping".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 7.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 35.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("msg_active_medications".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 22.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_no".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 18.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 37.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("lbl_drug_allergies".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 20.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_no".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 18.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 35.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("msg_medical_conditions".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 22.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_no".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 18.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 36.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("lbl_surgeries".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 20.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_no".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 18.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 37.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                        padding: EdgeInsets.only(left: 16.h),
                                        child: Text("lbl_family_history".tr,
                                            style: CustomTextStyles
                                                .titleMediumGray900))),
                                SizedBox(height: 20.v),
                                Padding(
                                    padding: EdgeInsets.only(
                                        left: 16.h, right: 26.h),
                                    child: _buildFrameThirteen(
                                        diificultySleeping: "lbl_no".tr,
                                        change: "lbl_change".tr)),
                                SizedBox(height: 18.v),
                                Divider(indent: 16.h, endIndent: 16.h),
                                SizedBox(height: 32.v),
                                _buildInputField(),
                                SizedBox(height: 23.v)
                              ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              title: Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Row(children: [
                    AppbarTitleButtonOne(
                        margin: EdgeInsets.symmetric(vertical: 1.v),
                        onTap: () {
                          onTapBack();
                        }),
                    AppbarTitle(
                        text: "lbl_review_profile".tr,
                        margin: EdgeInsets.only(left: 50.h))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildInputField() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        decoration: AppDecoration.outlineBlack90001,
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(height: 21.v),
              GestureDetector(
                  onTap: () {
                    onTapButtonBase();
                  },
                  child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 58.h),
                      decoration: AppDecoration.outlinePrimary.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder8),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                                padding: EdgeInsets.only(top: 12.v),
                                child: Text("lbl_next".tr,
                                    style:
                                        CustomTextStyles.titleMediumOnPrimary)),
                            Container(
                                height: 1.v,
                                width: 20.h,
                                margin: EdgeInsets.only(top: 23.v, bottom: 2.v),
                                decoration: BoxDecoration(
                                    color: theme.colorScheme.primaryContainer)),
                            Padding(
                                padding: EdgeInsets.only(top: 12.v),
                                child: Text("lbl_confirm_payment".tr,
                                    style: CustomTextStyles
                                        .titleMediumPrimaryContainer)),
                            CustomImageView(
                                imagePath: ImageConstant.imgArrowright,
                                height: 15.v,
                                width: 24.h,
                                margin: EdgeInsets.only(top: 12.v))
                          ])))
            ]));
  }

  /// Common widget
  Widget _buildFrameThirteen({
    required String diificultySleeping,
    required String change,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Expanded(
          child: SizedBox(
              width: 250.h,
              child: Text(diificultySleeping,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleMediumGray900_1
                      .copyWith(color: appTheme.gray900, height: 1.50)))),
      Padding(
          padding: EdgeInsets.only(left: 22.h, top: 12.v, bottom: 13.v),
          child: Text(change,
              style: CustomTextStyles.titleMediumPrimary
                  .copyWith(color: theme.colorScheme.primary)))
    ]);
  }

  /// Navigates to the bookAppointmentOneScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.bookAppointmentOneScreen,
    );
  }

  /// Navigates to the bookAppointmentScreen when the action is triggered.
  onTapButtonBase() {
    Get.toNamed(
      AppRoutes.bookAppointmentScreen,
    );
  }
}
