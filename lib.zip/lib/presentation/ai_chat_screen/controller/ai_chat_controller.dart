import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/ai_chat_screen/models/ai_chat_model.dart';

/// A controller class for the AiChatScreen.
///
/// This class manages the state of the AiChatScreen, including the
/// current aiChatModelObj
class AiChatController extends GetxController {
  Rx<AiChatModel> aiChatModelObj = AiChatModel().obs;
}
