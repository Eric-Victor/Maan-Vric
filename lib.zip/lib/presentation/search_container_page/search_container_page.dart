import '../search_container_page/widgets/searchcontainer_item_widget.dart';
import 'controller/search_container_controller.dart';
import 'models/search_container_model.dart';
import 'models/searchcontainer_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_search_view.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class SearchContainerPage extends StatelessWidget {
  SearchContainerPage({Key? key}) : super(key: key);

  SearchContainerController controller =
      Get.put(SearchContainerController(SearchContainerModel().obs));

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillOnPrimary,
                child: Column(children: [
                  Container(
                      height: 16.v,
                      width: double.maxFinite,
                      decoration:
                          BoxDecoration(color: appTheme.gray50Ef, boxShadow: [
                        BoxShadow(
                            color: appTheme.black90001.withOpacity(0.3),
                            spreadRadius: 2.h,
                            blurRadius: 2.h,
                            offset: Offset(0, 1))
                      ])),
                  Expanded(
                      child: SizedBox(
                          width: double.maxFinite,
                          child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16.h, vertical: 25.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: Column(children: [
                                _buildFrame(),
                                SizedBox(height: 11.v),
                                CustomSearchView(
                                    controller: controller.searchController,
                                    hintText: "msg_doctors_symptoms".tr),
                                SizedBox(height: 32.v),
                                _buildSearchContainer(),
                                SizedBox(height: 22.v)
                              ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildFrame() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text("lbl_search".tr, style: theme.textTheme.titleLarge),
      CustomOutlinedButton(
          height: 24.v,
          width: 112.h,
          text: "lbl_ekm_india".tr,
          leftIcon: Container(
              margin: EdgeInsets.only(right: 6.h),
              child: CustomImageView(
                  imagePath: ImageConstant.imgLocationon,
                  height: 18.adaptSize,
                  width: 18.adaptSize)),
          buttonStyle: CustomButtonStyles.outlinePrimaryContainerTL12,
          buttonTextStyle: theme.textTheme.titleSmall!)
    ]);
  }

  /// Section Widget
  Widget _buildSearchContainer() {
    return Expanded(
        child: Obx(() => GridView.builder(
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 171.v,
                crossAxisCount: 2,
                mainAxisSpacing: 10.h,
                crossAxisSpacing: 10.h),
            physics: BouncingScrollPhysics(),
            itemCount: controller.searchContainerModelObj.value
                .searchcontainerItemList.value.length,
            itemBuilder: (context, index) {
              SearchcontainerItemModel model = controller
                  .searchContainerModelObj
                  .value
                  .searchcontainerItemList
                  .value[index];
              return SearchcontainerItemWidget(model, onTapComponent: () {
                onTapComponent();
              });
            })));
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapComponent() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }
}
