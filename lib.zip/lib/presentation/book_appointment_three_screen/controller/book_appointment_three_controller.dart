import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/book_appointment_three_screen/models/book_appointment_three_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the BookAppointmentThreeScreen.
///
/// This class manages the state of the BookAppointmentThreeScreen, including the
/// current bookAppointmentThreeModelObj
class BookAppointmentThreeController extends GetxController {
  TextEditingController reasonController = TextEditingController();

  Rx<BookAppointmentThreeModel> bookAppointmentThreeModelObj =
      BookAppointmentThreeModel().obs;

  Rx<bool> difficultysleeping = false.obs;

  Rx<bool> fatigueweakness = false.obs;

  Rx<bool> fever = false.obs;

  Rx<String> radioGroup = "".obs;

  Rx<bool> moodchanges = false.obs;

  Rx<bool> nightsweats = false.obs;

  Rx<bool> congestions = false.obs;

  Rx<bool> earpain = false.obs;

  Rx<bool> eyeredness = false.obs;

  Rx<bool> headaches = false.obs;

  Rx<bool> lossofsmell = false.obs;

  Rx<bool> lossoftaste = false.obs;

  Rx<String> radioGroup1 = "".obs;

  @override
  void onClose() {
    super.onClose();
    reasonController.dispose();
  }
}
