import '../choose_doctor_screen/widgets/doctorscloseby_item_widget.dart';
import 'controller/choose_doctor_controller.dart';
import 'models/doctorscloseby_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_leading_image.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_subtitle.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_drop_down.dart';
import 'package:eric_s_application2/widgets/custom_search_view.dart';
import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class ChooseDoctorScreen extends GetWidget<ChooseDoctorController> {
  const ChooseDoctorScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  SizedBox(height: 5.v),
                  Expanded(
                      child: SizedBox(
                          width: double.maxFinite,
                          child: Container(
                              padding: EdgeInsets.symmetric(vertical: 24.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: Column(children: [
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 16.h),
                                    child: CustomSearchView(
                                        controller: controller.searchController,
                                        hintText: "lbl_search".tr)),
                                SizedBox(height: 24.v),
                                _buildSort(),
                                SizedBox(height: 43.v),
                                _buildDoctorsCloseBy(),
                                SizedBox(height: 5.v)
                              ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              leadingWidth: 32.h,
              leading: AppbarLeadingImage(
                  imagePath: ImageConstant.imgArrowleft,
                  margin: EdgeInsets.only(left: 8.h, top: 1.v, bottom: 1.v),
                  onTap: () {
                    onTapArrowLeft();
                  }),
              title: Padding(
                  padding: EdgeInsets.only(left: 4.h),
                  child: Row(children: [
                    AppbarSubtitle(
                        text: "lbl_back".tr,
                        margin: EdgeInsets.only(top: 2.v, bottom: 1.v)),
                    AppbarTitle(
                        text: "msg_medical_officers".tr,
                        margin: EdgeInsets.only(left: 37.h))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildSort() {
    return Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        decoration: AppDecoration.outlineBlueGray,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 16.v),
              child: CustomDropDown(
                  width: 139.h,
                  icon: Container(
                      margin: EdgeInsets.only(right: 4.h),
                      child: CustomImageView(
                          imagePath: ImageConstant.imgArrowdropdown,
                          height: 24.adaptSize,
                          width: 24.adaptSize)),
                  hintText: "lbl_available_today".tr,
                  items: controller
                      .chooseDoctorModelObj.value.dropdownItemList!.value,
                  borderDecoration: DropDownStyleHelper.fillPrimary,
                  fillColor: theme.colorScheme.primary,
                  onChanged: (value) {
                    controller.onSelected(value);
                  })),
          Padding(
              padding: EdgeInsets.symmetric(vertical: 16.v),
              child: CustomDropDown(
                  width: 96.h,
                  icon: Container(
                      margin: EdgeInsets.only(right: 4.h),
                      child: CustomImageView(
                          imagePath: ImageConstant.imgArrowdropdownBlueGray500,
                          height: 24.adaptSize,
                          width: 24.adaptSize)),
                  hintText: "lbl_in_person".tr,
                  hintStyle: theme.textTheme.titleSmall!,
                  items: controller
                      .chooseDoctorModelObj.value.dropdownItemList1!.value,
                  onChanged: (value) {
                    controller.onSelected1(value);
                  })),
          SizedBox(
              height: 72.v,
              width: 124.h,
              child: Stack(alignment: Alignment.centerRight, children: [
                CustomDropDown(
                    width: 104.h,
                    icon: Container(
                        margin: EdgeInsets.only(right: 8.h),
                        child: CustomImageView(
                            imagePath:
                                ImageConstant.imgArrowdropdownBlueGray500,
                            height: 24.adaptSize,
                            width: 24.adaptSize)),
                    hintText: "lbl_via_video".tr,
                    hintStyle: theme.textTheme.titleSmall!,
                    alignment: Alignment.centerLeft,
                    items: controller
                        .chooseDoctorModelObj.value.dropdownItemList2!.value,
                    contentPadding:
                        EdgeInsets.only(left: 7.h, top: 10.v, bottom: 10.v),
                    onChanged: (value) {
                      controller.onSelected2(value);
                    }),
                Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                        height: 72.v,
                        width: 44.h,
                        padding: EdgeInsets.fromLTRB(9.h, 24.v, 10.h, 24.v),
                        decoration: AppDecoration.outlinePrimaryContainer1,
                        child: CustomImageView(
                            imagePath: ImageConstant.imgFilterList,
                            height: 24.adaptSize,
                            width: 24.adaptSize,
                            alignment: Alignment.center)))
              ]))
        ]));
  }

  /// Section Widget
  Widget _buildDoctorsCloseBy() {
    return Expanded(
        child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            child: Obx(() => GroupedListView<DoctorsclosebyItemModel, String>(
                shrinkWrap: true,
                stickyHeaderBackgroundColor: Colors.transparent,
                elements: controller
                    .chooseDoctorModelObj.value.doctorsclosebyItemList.value,
                groupBy: (element) => element.groupBy!.value,
                sort: false,
                groupSeparatorBuilder: (String value) {
                  return Padding(
                      padding: EdgeInsets.only(top: 42.v, bottom: 21.v),
                      child: Text(value,
                          style: CustomTextStyles.titleLargeBlack90001
                              .copyWith(color: appTheme.black90001)));
                },
                itemBuilder: (context, model) {
                  return DoctorsclosebyItemWidget(model);
                },
                separator: SizedBox(height: 8.v)))));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft() {
    Get.back();
  }
}
