import 'controller/calendar_two_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container_page/search_container_page.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_bottom_bar.dart';
import 'package:eric_s_application2/widgets/custom_elevated_button.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class CalendarTwoScreen extends GetWidget<CalendarTwoController> {
  const CalendarTwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Container(
                      padding: EdgeInsets.symmetric(horizontal: 16.h),
                      child: Column(children: [
                        SizedBox(height: 24.v),
                        _buildFrame(),
                        SizedBox(height: 5.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("msg_see_all_your_appointments".tr,
                                style: theme.textTheme.titleMedium)),
                        SizedBox(height: 25.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("msg_today_s_appointment".tr,
                                style: CustomTextStyles.titleMediumGray900_1)),
                        SizedBox(height: 8.v),
                        _buildDoctor1(),
                        SizedBox(height: 8.v),
                        _buildAddAnAppointment(),
                        SizedBox(height: 8.v),
                        Divider(),
                        SizedBox(height: 24.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("lbl_tomorrow".tr,
                                style: CustomTextStyles.titleMediumGray900_1)),
                        SizedBox(height: 9.v),
                        _buildDoctorOne(),
                        SizedBox(height: 8.v),
                        Divider(),
                        SizedBox(height: 25.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("lbl_friday".tr,
                                style: CustomTextStyles.titleMediumGray900_1)),
                        SizedBox(height: 8.v),
                        _buildDoctorOne1(),
                        SizedBox(height: 8.v),
                        Divider(),
                        SizedBox(height: 26.v),
                        Align(
                            alignment: Alignment.centerLeft,
                            child: Text("lbl_saturday".tr,
                                style: CustomTextStyles.titleMediumGray900_1)),
                        SizedBox(height: 7.v),
                        _buildDoctor2(),
                        SizedBox(height: 8.v),
                        Divider()
                      ]))
                ])),
            bottomNavigationBar: _buildBottomBar()));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              centerTitle: true, title: AppbarTitle(text: "lbl_calendar".tr))
        ]));
  }

  /// Section Widget
  Widget _buildFrame() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.only(top: 8.v, bottom: 6.v),
          child: Text("lbl_appointments".tr,
              style: CustomTextStyles.titleMediumGray900)),
      Container(
          padding: EdgeInsets.symmetric(horizontal: 13.h, vertical: 9.v),
          decoration: AppDecoration.outlinePrimaryContainer2
              .copyWith(borderRadius: BorderRadiusStyle.circleBorder22),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            CustomImageView(
                imagePath: ImageConstant.imgTocPrimary,
                height: 20.adaptSize,
                width: 20.adaptSize),
            Padding(
                padding: EdgeInsets.only(left: 20.h),
                child: SizedBox(
                    height: 20.v,
                    child: VerticalDivider(
                        width: 1.h,
                        thickness: 1.v,
                        color: theme.colorScheme.primaryContainer))),
            CustomImageView(
                imagePath: ImageConstant.imgCalendarMonthBlueGray300,
                height: 20.adaptSize,
                width: 20.adaptSize,
                margin: EdgeInsets.only(left: 20.h),
                onTap: () {
                  onTapImgCalendarMonth();
                })
          ]))
    ]);
  }

  /// Section Widget
  Widget _buildDoctor1() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
        decoration: AppDecoration.fillOnPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
              height: 40.adaptSize,
              width: 40.adaptSize,
              margin: EdgeInsets.symmetric(vertical: 17.v),
              child: Stack(alignment: Alignment.bottomRight, children: [
                CustomImageView(
                    imagePath: ImageConstant.imgRectangle29,
                    height: 40.adaptSize,
                    width: 40.adaptSize,
                    radius: BorderRadius.circular(20.h),
                    alignment: Alignment.center),
                Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                        height: 10.adaptSize,
                        width: 10.adaptSize,
                        decoration: BoxDecoration(
                            color: appTheme.greenA700,
                            borderRadius: BorderRadius.circular(5.h),
                            border: Border.all(
                                color: appTheme.gray100,
                                width: 1.h,
                                strokeAlign: strokeAlignOutside))))
              ])),
          Padding(
              padding: EdgeInsets.only(left: 10.h),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        width: 128.h,
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.h, vertical: 2.v),
                        decoration: AppDecoration.fillBlue50.copyWith(
                            borderRadius: BorderRadiusStyle.circleBorder11),
                        child: Text("msg_video_consultation2".tr,
                            style: CustomTextStyles.labelLargeIndigo500)),
                    SizedBox(height: 3.v),
                    Text("msg_dr_jose_manavalan".tr,
                        style: CustomTextStyles.titleMediumBluegray90001),
                    SizedBox(height: 5.v),
                    RichText(
                        text: TextSpan(children: [
                          TextSpan(
                              text: "lbl_today_12_30pm".tr,
                              style:
                                  CustomTextStyles.titleMediumBluegray90001_1),
                          TextSpan(
                              text: "lbl_30mins".tr,
                              style: theme.textTheme.titleMedium)
                        ]),
                        textAlign: TextAlign.left)
                  ])),
          Spacer(),
          Padding(
              padding: EdgeInsets.symmetric(vertical: 17.v),
              child: CustomIconButton(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  padding: EdgeInsets.all(6.h),
                  decoration: IconButtonStyleHelper.fillTeal,
                  child: CustomImageView(
                      imagePath: ImageConstant.imgVideocamOnprimary)))
        ]));
  }

  /// Section Widget
  Widget _buildAddAnAppointment() {
    return CustomElevatedButton(
        height: 24.v,
        width: 193.h,
        text: "msg_add_an_appointment".tr,
        leftIcon: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        buttonStyle: CustomButtonStyles.none,
        buttonTextStyle: CustomTextStyles.titleMediumPrimary,
        onPressed: () {
          onTapAddAnAppointment();
        },
        alignment: Alignment.centerLeft);
  }

  /// Section Widget
  Widget _buildDoctorOne() {
    return CustomTextFormField(
        controller: controller.doctorOneController,
        hintText: "msg_book_an_appointment2".tr,
        hintStyle: CustomTextStyles.titleMediumPrimary,
        prefix: Container(
            margin: EdgeInsets.symmetric(horizontal: 10.h, vertical: 16.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        borderDecoration: TextFormFieldStyleHelper.fillOnPrimary);
  }

  /// Section Widget
  Widget _buildDoctorOne1() {
    return CustomTextFormField(
        controller: controller.doctorOneController1,
        hintText: "msg_book_an_appointment2".tr,
        hintStyle: CustomTextStyles.titleMediumPrimary,
        textInputAction: TextInputAction.done,
        prefix: Container(
            margin: EdgeInsets.symmetric(horizontal: 10.h, vertical: 16.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        borderDecoration: TextFormFieldStyleHelper.fillOnPrimary);
  }

  /// Section Widget
  Widget _buildBookAnAppointment() {
    return CustomElevatedButton(
        height: 24.v,
        width: 200.h,
        text: "msg_book_an_appointment2".tr,
        leftIcon: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        buttonStyle: CustomButtonStyles.none,
        buttonTextStyle: CustomTextStyles.titleMediumPrimary,
        onPressed: () {
          onTapBookAnAppointment();
        });
  }

  /// Section Widget
  Widget _buildDoctor2() {
    return Container(
        width: 358.h,
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 16.v),
        decoration: AppDecoration.fillOnPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: _buildBookAnAppointment());
  }

  /// Section Widget
  Widget _buildBottomBar() {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Get.toNamed(getCurrentRoute(type), id: 1);
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.searchContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Message:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.searchContainerPage:
        return SearchContainerPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the calendarScreen when the action is triggered.
  onTapImgCalendarMonth() {
    Get.toNamed(
      AppRoutes.calendarScreen,
    );
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapAddAnAppointment() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }

  /// Navigates to the bookAppointmentFourScreen when the action is triggered.
  onTapBookAnAppointment() {
    Get.toNamed(
      AppRoutes.bookAppointmentFourScreen,
    );
  }
}
