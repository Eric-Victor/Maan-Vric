import '../book_appointment_four_screen/widgets/bookappointmentfour_item_widget.dart';
import 'controller/book_appointment_four_controller.dart';
import 'models/bookappointmentfour_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class BookAppointmentFourScreen
    extends GetWidget<BookAppointmentFourController> {
  const BookAppointmentFourScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(bottom: 5.v),
                              child: Column(children: [
                                SizedBox(
                                    height: 1278.v,
                                    width: double.maxFinite,
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Container(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 15.h,
                                                      vertical: 26.v),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                            "msg_who_is_this_appointment"
                                                                .tr,
                                                            style: CustomTextStyles
                                                                .titleMediumBlack90001),
                                                        SizedBox(height: 16.v),
                                                        Row(children: [
                                                          Column(children: [
                                                            CustomIconButton(
                                                                height: 50
                                                                    .adaptSize,
                                                                width: 50
                                                                    .adaptSize,
                                                                padding:
                                                                    EdgeInsets
                                                                        .all(10
                                                                            .h),
                                                                decoration:
                                                                    IconButtonStyleHelper
                                                                        .outlinePrimary,
                                                                child: CustomImageView(
                                                                    imagePath:
                                                                        ImageConstant
                                                                            .imgImage)),
                                                            SizedBox(
                                                                height: 4.v),
                                                            Text("lbl_rahul".tr,
                                                                style: CustomTextStyles
                                                                    .titleMediumGray900_1)
                                                          ]),
                                                          Padding(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      left:
                                                                          32.h),
                                                              child: Column(
                                                                  children: [
                                                                    CustomIconButton(
                                                                        height: 50
                                                                            .adaptSize,
                                                                        width: 50
                                                                            .adaptSize,
                                                                        padding:
                                                                            EdgeInsets.all(13
                                                                                .h),
                                                                        decoration:
                                                                            IconButtonStyleHelper
                                                                                .outlinePrimaryContainer,
                                                                        child: CustomImageView(
                                                                            imagePath:
                                                                                ImageConstant.imgAdd)),
                                                                    SizedBox(
                                                                        height:
                                                                            4.v),
                                                                    Text(
                                                                        "lbl_add_individual"
                                                                            .tr,
                                                                        style: theme
                                                                            .textTheme
                                                                            .titleMedium)
                                                                  ]))
                                                        ]),
                                                        SizedBox(height: 36.v),
                                                        Text(
                                                            "msg_what_is_the_patient_s"
                                                                .tr,
                                                            style: CustomTextStyles
                                                                .titleMediumBlack90001),
                                                        SizedBox(height: 16.v),
                                                        Container(
                                                            width: 349.h,
                                                            margin:
                                                                EdgeInsets.only(
                                                                    right: 8.h),
                                                            child: Text(
                                                                "msg_this_would_help"
                                                                    .tr,
                                                                maxLines: 3,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                style: theme
                                                                    .textTheme
                                                                    .titleMedium!
                                                                    .copyWith(
                                                                        height:
                                                                            1.50))),
                                                        SizedBox(height: 17.v),
                                                        Row(children: [
                                                          CustomImageView(
                                                              imagePath:
                                                                  ImageConstant
                                                                      .imgPinDrop,
                                                              height:
                                                                  24.adaptSize,
                                                              width:
                                                                  24.adaptSize),
                                                          Padding(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      left:
                                                                          10.h),
                                                              child: Text(
                                                                  "lbl_edapally_kochi"
                                                                      .tr,
                                                                  style: CustomTextStyles
                                                                      .titleMediumGray900_1)),
                                                          Padding(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                      left:
                                                                          20.h),
                                                              child: Text(
                                                                  "lbl_change"
                                                                      .tr,
                                                                  style: CustomTextStyles
                                                                      .titleMediumPrimary))
                                                        ]),
                                                        SizedBox(height: 44.v),
                                                        Text(
                                                            "msg_what_s_the_main"
                                                                .tr,
                                                            style: CustomTextStyles
                                                                .titleMediumBlack90001),
                                                        SizedBox(height: 16.v),
                                                        _buildReasons(),
                                                        SizedBox(height: 21.v)
                                                      ]))),
                                          _buildTile()
                                        ])),
                                SizedBox(height: 27.v),
                                _buildWarning()
                              ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 16.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 4.v),
              CustomAppBar(
                  title: Padding(
                      padding: EdgeInsets.only(left: 8.h),
                      child: Row(children: [
                        AppbarTitleButton(
                            margin: EdgeInsets.only(bottom: 3.v),
                            onTap: () {
                              onTapHome();
                            }),
                        AppbarTitle(
                            text: "lbl_appointments".tr,
                            margin: EdgeInsets.only(left: 46.h))
                      ])))
            ]));
  }

  /// Section Widget
  Widget _buildReasons() {
    return Column(children: [
      Obx(() => GridView.builder(
          shrinkWrap: true,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              mainAxisExtent: 171.v,
              crossAxisCount: 2,
              mainAxisSpacing: 10.h,
              crossAxisSpacing: 10.h),
          physics: NeverScrollableScrollPhysics(),
          itemCount: controller.bookAppointmentFourModelObj.value
              .bookappointmentfourItemList.value.length,
          itemBuilder: (context, index) {
            BookappointmentfourItemModel model = controller
                .bookAppointmentFourModelObj
                .value
                .bookappointmentfourItemList
                .value[index];
            return BookappointmentfourItemWidget(model);
          })),
      SizedBox(height: 16.v),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Expanded(
            child: Container(
                margin: EdgeInsets.only(right: 5.h),
                padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 13.v),
                decoration: AppDecoration.fillPurple,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Card(
                          clipBehavior: Clip.antiAlias,
                          elevation: 0,
                          margin: EdgeInsets.all(0),
                          color: appTheme.pink50,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadiusStyle.circleBorder22),
                          child: Container(
                              height: 44.adaptSize,
                              width: 44.adaptSize,
                              padding: EdgeInsets.all(10.h),
                              decoration: AppDecoration.fillPink.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.circleBorder22),
                              child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFemalePink400,
                                        height: 18.adaptSize,
                                        width: 18.adaptSize,
                                        alignment: Alignment.bottomLeft),
                                    CustomImageView(
                                        imagePath: ImageConstant.imgMalePink400,
                                        height: 18.adaptSize,
                                        width: 18.adaptSize,
                                        alignment: Alignment.topRight)
                                  ]))),
                      SizedBox(height: 9.v),
                      SizedBox(
                          width: 81.h,
                          child: Text("msg_sex_health_education".tr,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: CustomTextStyles.titleMediumGray900_1
                                  .copyWith(height: 1.50))),
                      SizedBox(height: 1.v),
                      Text("lbl_find_a_doctor".tr,
                          style: CustomTextStyles.labelLargeBluegray70002),
                      SizedBox(height: 24.v)
                    ]))),
        Expanded(
            child: Container(
                margin: EdgeInsets.only(left: 5.h),
                padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 13.v),
                decoration: AppDecoration.fillIndigo,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomIconButton(
                          height: 44.adaptSize,
                          width: 44.adaptSize,
                          padding: EdgeInsets.all(10.h),
                          decoration: IconButtonStyleHelper.fillBlueGray,
                          child: CustomImageView(
                              imagePath: ImageConstant.imgHelpCenter)),
                      SizedBox(height: 8.v),
                      SizedBox(
                          width: 110.h,
                          child: Text("msg_other_medical_reasons".tr,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: CustomTextStyles.titleMediumGray900_1
                                  .copyWith(height: 1.50))),
                      SizedBox(height: 1.v),
                      Text("lbl_find_a_doctor".tr,
                          style: CustomTextStyles.labelLargeIndigo700),
                      SizedBox(height: 24.v)
                    ])))
      ])
    ]);
  }

  /// Section Widget
  Widget _buildTile() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Container(
            margin: EdgeInsets.only(left: 16.h, top: 1180.v, right: 16.h),
            padding: EdgeInsets.symmetric(vertical: 13.v),
            decoration: AppDecoration.outlineBluegray8000f
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder30),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Padding(
                      padding: EdgeInsets.symmetric(vertical: 15.v),
                      child: CustomIconButton(
                          height: 40.adaptSize,
                          width: 40.adaptSize,
                          padding: EdgeInsets.all(8.h),
                          decoration: IconButtonStyleHelper.fillPurpleTL20,
                          child: CustomImageView(
                              imagePath:
                                  ImageConstant.imgEosIconsAiHealingOutlined))),
                  Padding(
                      padding: EdgeInsets.only(top: 1.v),
                      child: Column(children: [
                        Text("msg_consult_with_an".tr,
                            style: CustomTextStyles.titleMediumLightgreen800),
                        SizedBox(height: 5.v),
                        SizedBox(
                            width: 227.h,
                            child: Text("msg_ai_assistant_offering".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.titleSmall!
                                    .copyWith(height: 1.43)))
                      ])),
                  CustomImageView(
                      imagePath: ImageConstant.imgIconright,
                      height: 24.adaptSize,
                      width: 24.adaptSize,
                      margin: EdgeInsets.symmetric(vertical: 23.v),
                      onTap: () {
                        onTapImgIconRight();
                      })
                ])));
  }

  /// Section Widget
  Widget _buildWarning() {
    return Container(
        margin: EdgeInsets.symmetric(horizontal: 16.h),
        padding: EdgeInsets.symmetric(horizontal: 11.h, vertical: 8.v),
        decoration: AppDecoration.fillBlueGray,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          SizedBox(height: 1.v),
          SizedBox(
              width: 333.h,
              child: Text("msg_for_medical_emergencies".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.titleMediumBluegray80001
                      .copyWith(height: 1.50)))
        ]));
  }

  /// Navigates to the homeScreen when the action is triggered.
  onTapHome() {
    Get.toNamed(
      AppRoutes.homeScreen,
    );
  }

  /// Navigates to the aiChatScreen when the action is triggered.
  onTapImgIconRight() {
    Get.toNamed(
      AppRoutes.aiChatScreen,
    );
  }
}
