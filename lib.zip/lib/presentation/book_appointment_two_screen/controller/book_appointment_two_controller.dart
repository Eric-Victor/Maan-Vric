import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/book_appointment_two_screen/models/book_appointment_two_model.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:flutter/material.dart';

/// A controller class for the BookAppointmentTwoScreen.
///
/// This class manages the state of the BookAppointmentTwoScreen, including the
/// current bookAppointmentTwoModelObj
class BookAppointmentTwoController extends GetxController with CodeAutoFill {
  TextEditingController reasonController = TextEditingController();

  Rx<TextEditingController> otpController = TextEditingController().obs;

  Rx<BookAppointmentTwoModel> bookAppointmentTwoModelObj =
      BookAppointmentTwoModel().obs;

  @override
  void codeUpdated() {
    otpController.value.text = code ?? '';
  }

  @override
  void onInit() {
    super.onInit();
    listenForCode();
  }

  @override
  void onClose() {
    super.onClose();
    reasonController.dispose();
  }
}
