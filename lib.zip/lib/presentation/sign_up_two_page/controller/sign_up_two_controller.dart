import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/sign_up_two_page/models/sign_up_two_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignUpTwoPage.
///
/// This class manages the state of the SignUpTwoPage, including the
/// current signUpTwoModelObj
class SignUpTwoController extends GetxController {
  SignUpTwoController(this.signUpTwoModelObj);

  TextEditingController inputController = TextEditingController();

  Rx<SignUpTwoModel> signUpTwoModelObj;

  @override
  void onClose() {
    super.onClose();
    inputController.dispose();
  }
}
