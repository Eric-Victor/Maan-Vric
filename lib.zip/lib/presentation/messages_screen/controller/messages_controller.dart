import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/messages_screen/models/messages_model.dart';

/// A controller class for the MessagesScreen.
///
/// This class manages the state of the MessagesScreen, including the
/// current messagesModelObj
class MessagesController extends GetxController {
  Rx<MessagesModel> messagesModelObj = MessagesModel().obs;
}
