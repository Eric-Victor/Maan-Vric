final Map<String, String> enUs = {
  // Homescreen Screen
  "msg_your_personal_health": "Your Personal Health Partner",

  // Onboarding One Screen
  "msg_these_are_specialists":
      "These are Specialists in their respective fields, which includes Brain & Nervous system",
  "msg_video_consult_top":
      "Video consult top doctors from the comfort of your home.",

  // Login Screen
  "lbl_or_sign_in_with": "or Sign In with",
  "lbl_sign_up": "Sign Up",
  "msg_don_t_have_an_account": "Don’t have an account? Sign Up",
  "msg_don_t_have_an_account2": "Don’t have an account? ",
  "msg_enter_your_password": "Enter your password",
  "msg_forgot_password": "Forgot Password?",
  "msg_remember_for_30": "Remember for 30 days",
  "msg_sign_in_to_your": "Sign in to your account",
  "msg_sign_in_with_google": "Sign in with Google",
  "msg_welcome_back_you": "Welcome back! You have been missed.",

  // Sign Up Screen
  "lbl_and": ", and ",
  "lbl_privacy_policy": "Privacy Policy",
  "msg_8_characters_minimum": "8 characters minimum",
  "msg_already_have_an": "Already have an account? Sign In",
  "msg_already_have_an2": "Already have an account? ",
  "msg_by_clicking_continue":
      "By clicking “Continue”, you agree to accept our Privacy Policy, and Terms of Service ",
  "msg_by_clicking_continue2":
      "By clicking “Continue”, you agree to accept our ",
  "msg_let_s_get_you_started":
      "Let’s get you started. Please enter your details",
  "msg_password_strength": "Password strength:",
  "msg_terms_of_service": "Terms of Service ",

  // Sign Up Two Screen
  "lbl_aadhar_number": "Aadhar number",
  "msg_by_providing_your":
      "By providing your mobile number, you give us permission to contact you via text.",

  // Sign Up Two - Tab Container Screen
  "lbl_91": "+91 ",
  "lbl_date_of_birth": "Date of birth",
  "lbl_day": "Day",
  "lbl_female": "Female",
  "lbl_first_name": "First Name",
  "lbl_gender": "Gender",
  "lbl_ind": "IND",
  "lbl_last_name": "Last Name",
  "lbl_male": "Male",
  "lbl_month": "Month",
  "lbl_phone_number": "Phone number",
  "lbl_year": "Year",
  "msg_basic_information": "Basic Information",
  "msg_please_tell_us_some":
      "Please tell us some basic information to complete your profile:",

  // Sign Up One Screen
  "lbl_save": "Save",
  "lbl_skip_insurance": "Skip Insurance",
  "msg_e_g_star_insurance": "e.g Star Insurance",
  "msg_health_insurance": "Health Insurance",
  "msg_search_for_your":
      "Search for your health insurance provider to see if you’re cover.",
  "msg_you_can_see_a_doctor": "You can see a doctor without insurance",

  // Home Screen
  "lbl_hi_rahul": "Hi Rahul!",
  "lbl_men_s_health": "Men’s Health",
  "lbl_senior_health": "Senior Health",
  "lbl_women_s_health": "Women’s Health",
  "msg_book_an_appointment": "Book an appointment today!",
  "msg_chat_by_video_with": "Chat by video with the next available doctor.",
  "msg_children_s_health": "Children’s Health",
  "msg_choos_a_primary":
      "Choos a Primary Care Doctor and complete your first video appointment.",
  "msg_cold_flu_symptoms":
      "Cold & flu symptoms, Diarrhea or Constipation, Skin rashed, & Allergies ",
  "msg_for_general_needs": "For General Needs",
  "msg_for_specific_needs": "For Specific Needs",
  "msg_get_medical_advice":
      "Get medical advice, prescriptions, test & referrals by video appointment with our doctors.",
  "msg_get_medical_advice2": "Get medical advice, precriptions, test & more.",
  "msg_locate_a_pharmacy2":
      "Locate a Pharmacy within your area to purchase medications.",
  "msg_muscle_or_joint":
      "Muscle or joint pain, Medication management, Preventive health method.",
  "msg_our_primary_care":
      "Our primary care doctors can help you with a broad range of health issues, medications and more by video appointment.",
  "msg_request_urgent_care": "Request Urgent Care",
  "msg_see_more_actions": "See more actions",
  "msg_sti_symptoons_erection":
      "STI symptoons, Erection issues, Bladder or Bowel issues, Skin & hair care.",
  "msg_talk_to_a_doctor": "Talk to a Doctor",
  "msg_upcoming_appointments": "Upcoming Appointments",
  "msg_uti_birth_control":
      "UTI, Birth control, Menopause, Period problems, Yeast infections, & more.",
  "msg_what_do_you_want": "What do you want to do today?",
  "msg_you_currently_have": "You currently have 1 appointment scheduled.",

  // Book appointment Four Screen
  "lbl_add_individual": "Add individual",
  "lbl_edapally_kochi": "Edapally,Kochi",
  "lbl_rahul": "Rahul",
  "msg_ai_assistant_offering":
      "AI assistant offering personalized health insights and assistance ",
  "msg_consult_with_an": "Consult with an AI Assistant",
  "msg_covid_19_symptoms": "COVID-19 Symptoms",
  "msg_existing_or_chronic": "Existing or Chronic condition",
  "msg_for_medical_emergencies":
      "For medical emergencies, please call 112 or go to the nearest emergency hospital.",
  "msg_general_mental_health": "General Mental Health Concerns",
  "msg_other_medical_reasons": "Other Medical Reasons",
  "msg_prescriptions_or": "Prescriptions or Refills",
  "msg_routine_checkup": "Routine checkup, Follow-up or Screening",
  "msg_sex_health_education": "Sex Health Education",
  "msg_talk_to_a_pharmacist": "Talk to a Pharmacist",
  "msg_this_would_help":
      "This would help us connect you with the best available licensed Doctor for that location on our platform.",
  "msg_what_is_the_patient_s": "What is the patient’s current location?",
  "msg_what_s_the_main": "What’s the main reason for your visit?",
  "msg_who_is_this_appointment": "Who is this appointment for?",

  // Choose doctor Screen
  "lbl_1031_ratings": "1031 Ratings.",
  "lbl_apollo_hospital": "Apollo Hospital",
  "lbl_available_today": "Available Today",
  "lbl_cardiologist": "Cardiologist",
  "lbl_dermatologist": "Dermatologist",
  "lbl_dr_ahmed_anwar": "Dr. Ahmed Anwar",
  "lbl_dr_cijo_alex": "Dr. Cijo Alex",
  "lbl_dr_mohan_n_d": "Dr. Mohan N. D",
  "lbl_dr_suma_das": "Dr. Suma Das",
  "lbl_endocrinologist": "Endocrinologist",
  "lbl_fortis_hospital": "Fortis Hospital",
  "lbl_gynaecologist": "Gynaecologist",
  "lbl_in_person": "In-Person",
  "lbl_pediatrician": "Pediatrician",
  "lbl_surgeon": "Surgeon",
  "lbl_via_video": "Via Video",
  "msg_available_doctors": "Available doctors",
  "msg_birla_specialist": "Birla Specialist Hospital",
  "msg_doctors_close_by": "Doctors close-by",
  "msg_dr_c_s_hari_kumar": "Dr. C.S. Hari Kumar",
  "msg_dr_john_philips": "Dr. John Philips",
  "msg_dr_k_krishnamoorthy": "Dr. K. Krishnamoorthy Venkatesh",
  "msg_gastroenterologist": "Gastroenterologist",
  "msg_general_physician": "General Physician",
  "msg_hope_general_hospital": "Hope General Hospital",
  "msg_jeevan_jyothi_hospital": "Jeevan Jyothi Hospital",
  "msg_lifeline_hospital": "Lifeline Hospital",
  "msg_medical_officers": "Medical Officers",
  "msg_noble_specialist": "Noble Specialist Hospital",
  "msg_silver_crest_hospital": "Silver Crest Hospital",

  // Calendar One Screen
  "lbl_12_00_pm": "12:00 PM",
  "lbl_add_attachments": "Add Attachments",
  "lbl_attachments": "ATTACHMENTS",
  "lbl_date_time": "DATE & TIME",
  "lbl_doctor": "DOCTOR",
  "lbl_heath_profile": "Heath Profile",
  "lbl_medical_officer": "Medical Officer",
  "lbl_note": "NOTE",
  "lbl_service": "SERVICE",
  "msg_22nd_wed_june_2022": "22nd Wed, June 2022",
  "msg_confirm_a_date_and":
      "Confirm a date and time for your appointment with a general practictioner. Include a note aswell",
  "msg_mbbs_md_general": "MBBS, MD (General Physician)",
  "msg_type_your_complaints": "Type your complaints....",
  "msg_video_consultation": "Video Consultation (₹5,700)",

  // Book appointment Three Screen
  "lbl_3": "3",
  "lbl_congestions": "Congestions",
  "lbl_days": "Days",
  "lbl_ear_pain": "Ear pain",
  "lbl_eye_redness": "Eye redness",
  "lbl_fever": "Fever",
  "lbl_head_neck": "Head / Neck",
  "lbl_headaches": "Headaches",
  "lbl_how_long": "How Long",
  "lbl_loss_of_smell": "Loss of smell",
  "lbl_loss_of_taste": "Loss of taste",
  "lbl_medication_1": "Medication 1",
  "lbl_mood_changes": "Mood changes",
  "lbl_night_sweats": "Night sweats",
  "msg_add_new_medication": "Add new medication",
  "msg_are_you_currently": "Are you currently taking any medications?",
  "msg_difficulty_sleeping": "Difficulty sleeping",
  "msg_do_you_have_any": "Do you have any of these symptoms?",
  "msg_fatigue_weakness": "Fatigue / weakness",
  "msg_general_symptoms": "General symptoms",
  "msg_kindly_provide_the":
      "Kindly provide the patient’s medical information and history.",
  "msg_list_medications": "List medications below:",
  "msg_loss_of_appetite": "Loss of appetite",
  "msg_please_consider":
      "Please consider any medications you are currenty taking, including those taken in a regular basis.",

  // Book appointment One Screen
  "msg_are_you_allergic": "Are you allergic to any of the drugs listed?",
  "msg_do_you_have_any2": "Do you have any medical conditions?",
  "msg_examples_amoxicillin": "Examples: Amoxicillin, Bactrim, Aspirin",
  "msg_examples_appendectomy":
      "Examples: Appendectomy, Tonsillectomy, Knee replacement.",
  "msg_examples_high_cholesterol":
      "Examples: High Cholesterol, Insomnia, Asthma",
  "msg_has_anyone_in_your":
      "Has anyone in your family had any medical conditions?",
  "msg_have_you_had_any": "Have you had any surgeries?",
  "msg_not_sure_choose":
      "Not sure? Choose yes to browse a list of conditions and diseases.",
  "msg_please_only_include":
      "Please only include first-degree relatives (parents, siblings, and children)",
  "msg_see_list_the_medications":
      "See list the medications you might be allergic to below.",

  // Book appointment Two Screen
  "lbl_3_days": "3 Days",
  "lbl_confirm_payment": "Confirm Payment",
  "lbl_drug_allergies": "Drug Allergies",
  "lbl_family_history": "Family History",
  "lbl_surgeries": "Surgeries",
  "msg_active_medications": "Active Medications",
  "msg_diificulty_sleeping": "Diificulty sleeping, Fever, Loss of tatse",
  "msg_list_of_symptoms": "List of symptoms",
  "msg_make_sure_all_details":
      "Make sure all details are correct as these information would aid the Medical Practictioner.",
  "msg_medical_conditions": "Medical Conditions",

  // Book appointment Screen
  "lbl_0_00": "₹0.00",
  "lbl_5_700": "₹5,700",
  "lbl_add_insurance": "Add Insurance",
  "lbl_add_promo_code": "Add Promo Code",
  "lbl_card_numbers": "Card Numbers",
  "lbl_cvv": "CVV",
  "lbl_discount": "Discount ",
  "lbl_mm_yy": "MM / YY",
  "lbl_order_summary": "ORDER SUMMARY",
  "lbl_other_services": "Other Services",
  "lbl_pay": "Pay",
  "lbl_pay_5_700": "Pay ₹5,700 ",
  "lbl_rahul_s_visit": "Rahul’s Visit",
  "lbl_today_s_total": "Today’s Total",
  "lbl_xxx": "XXX",
  "msg_0000_0000_0000": "0000 - 0000 - 0000 - 0000",
  "msg_22nd_wed_june": "22nd Wed, June, 2022 at 12:30PM CAT",
  "msg_add_your_insurance":
      "Add your insurance plan for additional potential savings and discounts.",
  "msg_card_expiriation": "Card Expiriation",
  "msg_card_holders_name": "Card Holders Name",
  "msg_card_holders_name2": "Card holders Name",
  "msg_credit_crad_debit": "Credit Crad, Debit Card & E-wallet",
  "msg_general_physician2": "General Physician, Silver Crest Hospital",
  "msg_make_payment_to":
      "Make payment to confirm your appointment with your doctor. ",
  "msg_primary_care_visit": "Primary Care Visit Fee",
  "msg_select_payment_method": "Select Payment Method",
  "msg_use_health_insurance": "Use Health Insurance",
  "msg_with_dr_jose_manavalan": "With Dr. Jose Manavalan",

  // Pop-up Screen
  "msg_22nd_wednesday": "22nd Wednesday, June 2022 at 12:30PM CAT",
  "msg_dr_jose_manavalan2": "Dr. Jose Manavalan ",
  "msg_has_been_scheduled": "has been scheduled",
  "msg_make_sure_video":
      "Make sure video, audio and internet connections are working.",
  "msg_test_your_device": "Test your device prior to visit",
  "msg_your_upcoming_virtual":
      "Your upcoming virtual meeting with Dr. Jose Manavalan has been scheduled",
  "msg_your_upcoming_virtual2": "Your upcoming virtual meeting with ",

  // AI CHAT Screen
  "lbl_ai_doc": "AI Doc",
  "lbl_dr_chatbot": "Dr. Chatbot",
  "msg_doc_i_ve_got_fever":
      "Doc, I've got fever that comes and goes, intense chills and sweats, pounding headache, muscle aches like I've been in a gym marathon, constant fatigue, and this persistent nausea. My spleen and liver are making their presence known too – what are your thoughts?",
  "msg_hey_rahul_how_can": "Hey Rahul, how can I help you today.",
  "msg_i_m_sorry_to_hear":
      "I'm sorry to hear about your symptoms.I recommend a virtual meeting with a general physician as soon as possible.",

  // Search - Container Screen
  "lbl_ekm_india": "Ekm, India",
  "lbl_health_q_a": "Health Q&A",
  "msg_doctors_symptoms": "Doctors, Symptoms, Hospitals....",
  "msg_emergency_situation": "Emergency Situation",
  "msg_find_a_health_center": "Find a Health Center",
  "msg_find_the_nearest": "Find the Nearest Clinic",
  "msg_get_tested_at_home": "Get Tested at Home",
  "msg_order_a_lab_test": "Order a Lab Test",
  "msg_purchase_medications": "Purchase Medications",
  "msg_request_a_physical": "Request a Physical Consultation",
  "msg_request_an_ambulance": "Request an Ambulance",
  "msg_speak_to_a_doctor": "Speak to a Doctor",
  "msg_speak_to_a_physician": "Speak to a Physician.",
  "msg_symptoms_assessments": "Symptoms Assessments",

  // Calendar Screen
  "lbl_10_am": "10 AM",
  "lbl_11_am": "11 AM",
  "lbl_12_pm": "12 PM",
  "lbl_1_pm": "1 PM",
  "lbl_2_pm": "2 PM",
  "lbl_4_pm": "4 PM",
  "lbl_5_pm": "5 PM",
  "lbl_6_pm": "6 PM",
  "lbl_7_pm": "7 PM",
  "msg_appointment_with": "Appointment with Dr. Jose Manavalan",

  // Calendar Two Screen
  "lbl_friday": "Friday",
  "lbl_saturday": "Saturday",
  "lbl_tomorrow": "Tomorrow",
  "msg_add_an_appointment": "Add an Appointment",
  "msg_today_s_appointment": "Today’s Appointment",

  // Messages Screen
  "lbl_dr_jose": "Dr. Jose",
  "msg_hey_rahul_following":
      "Hey Rahul, following from our last meeting I wanted to remind you of the medications you were to take along side the Malaria medications.",
  "msg_thanks_for_the_reminder":
      "Thanks for the reminder. I wasn’t able to get the Paracetamol but got Panadol-Extra instead. I hope no issues?",
  "msg_that_s_fine_hope": "That’s fine. Hope you’re getting better?",
  "msg_yes_i_am_a_lot":
      "Yes, I am a lot better. Product designing is taking a toll on me. I need a vaction after this.. But i’m very much open to take more jobs.",

  // Profile Screen
  "lbl_account": "Account",
  "lbl_help_support": "Help & Support",
  "lbl_log_out": "Log Out",
  "lbl_mi_band_4": "MI Band 4",
  "lbl_payment": "Payment",
  "lbl_settings": "Settings",
  "lbl_transactios": "Transactios",
  "lbl_view": "View",
  "msg_24_7_customer_support": "24/7 customer support",
  "msg_configure_tyour": "Configure tyour account your way",
  "msg_heart_rate": "Heart Rate                       :               86 BPM",
  "msg_male_27_years_old": "Male, 27 years old.",
  "msg_mastercard_8976": "Mastercard ****8976",
  "msg_payment_method_on": "Payment method on file",
  "msg_securely_logout": "Securely Logout of the site.",

  // Common String
  "lbl_15_min_ago": "15 min ago",
  "lbl_21_min_ago": "21 min ago",
  "lbl_2_min_ago": "2 min ago",
  "lbl_30mins": "(30mins)",
  "lbl_appointments": "Appointments",
  "lbl_back": "Back",
  "lbl_calendar": "Calendar",
  "lbl_change": "(Change)",
  "lbl_continue": "Continue",
  "lbl_email": "Email",
  "lbl_find_a_doctor": "Find a Doctor",
  "lbl_health_profile": "Health Profile",
  "lbl_home": "Home",
  "lbl_maanvric": "Maanvric",
  "lbl_message": "Message",
  "lbl_next": "Next",
  "lbl_no": "No",
  "lbl_now": "Now",
  "lbl_password": "Password",
  "lbl_profile": "Profile",
  "lbl_rahul_menon": "Rahul Menon",
  "lbl_review_profile": "Review Profile",
  "lbl_search": "Search",
  "lbl_sign_in": "Sign In",
  "lbl_today_12_30pm": "Today, 12:30pm ",
  "lbl_yes": "Yes",
  "msg_book_an_appointment2": "Book an Appointment",
  "msg_create_an_account": "Create an account",
  "msg_dr_jose_manavalan": "Dr. Jose Manavalan",
  "msg_example_email_com": "example@email.com",
  "msg_how_long_have_you": "How long have you felt this way?",
  "msg_locate_a_pharmacy": "Locate a Pharmacy",
  "msg_new_health_concern": "New Health Concern",
  "msg_see_all_your_appointments": "See all your appointments",
  "msg_talk_to_a_specialist": "Talk to a Specialist",
  "msg_today_12_30pm_30mins": "Today, 12:30pm (30mins)",
  "msg_video_consultation2": "Video Consultation",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_email": "Please enter valid email",
  "err_msg_please_enter_valid_password": "Please enter valid password",
  "err_msg_please_enter_valid_text": "Please enter valid text",
};
