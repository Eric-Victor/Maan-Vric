import 'controller/book_appointment_three_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button_one.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_checkbox_button.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_radio_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class BookAppointmentThreeScreen
    extends GetWidget<BookAppointmentThreeController> {
  const BookAppointmentThreeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Container(
                              height: 1033.v,
                              width: double.maxFinite,
                              margin: EdgeInsets.only(bottom: 5.v),
                              padding: EdgeInsets.symmetric(vertical: 24.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                            padding: EdgeInsets.only(
                                                left: 16.h, right: 12.h),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                      width: 278.h,
                                                      margin: EdgeInsets.only(
                                                          right: 83.h),
                                                      child: Text(
                                                          "msg_kindly_provide_the"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 8.v),
                                                  CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgProgressbarPrimarycontainer,
                                                      height: 3.v,
                                                      width: 358.h),
                                                  SizedBox(height: 40.v),
                                                  _buildReason(),
                                                  SizedBox(height: 42.v),
                                                  Text(
                                                      "msg_how_long_have_you"
                                                          .tr,
                                                      style: CustomTextStyles
                                                          .titleMediumGray900),
                                                  SizedBox(height: 8.v),
                                                  Row(children: [
                                                    _buildThree(),
                                                    Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 16.h,
                                                                top: 18.v,
                                                                bottom: 15.v),
                                                        child: Text(
                                                            "lbl_days".tr,
                                                            style: CustomTextStyles
                                                                .titleMediumGray900_1)),
                                                    CustomImageView(
                                                        imagePath: ImageConstant
                                                            .imgIconrightBlueGray70001,
                                                        height: 24.adaptSize,
                                                        width: 24.adaptSize,
                                                        margin: EdgeInsets.only(
                                                            left: 10.h,
                                                            top: 16.v,
                                                            bottom: 15.v))
                                                  ]),
                                                  SizedBox(height: 43.v),
                                                  Text("msg_do_you_have_any".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumGray900),
                                                  SizedBox(height: 9.v),
                                                  Text(
                                                      "msg_general_symptoms".tr,
                                                      style: theme.textTheme
                                                          .titleMedium),
                                                  SizedBox(height: 9.v),
                                                  _buildFrameFortySix(),
                                                  SizedBox(height: 8.v),
                                                  _buildFrameFortySeven(),
                                                  SizedBox(height: 10.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 51.h),
                                                      child: Row(children: [
                                                        _buildMoodchanges(),
                                                        _buildNightsweats()
                                                      ])),
                                                  SizedBox(height: 15.v),
                                                  Text("lbl_head_neck".tr,
                                                      style: theme.textTheme
                                                          .titleMedium),
                                                  SizedBox(height: 11.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 86.h),
                                                      child: Row(children: [
                                                        _buildCongestions(),
                                                        _buildEarpain()
                                                      ])),
                                                  SizedBox(height: 8.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 63.h),
                                                      child: Row(children: [
                                                        _buildEyeredness(),
                                                        _buildHeadaches()
                                                      ])),
                                                  SizedBox(height: 8.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 55.h),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            _buildLossofsmell(),
                                                            _buildLossoftaste()
                                                          ])),
                                                  SizedBox(height: 43.v),
                                                  _buildInputField()
                                                ]))),
                                    _buildInputField1()
                                  ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              title: Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Row(children: [
                    AppbarTitleButtonOne(
                        margin: EdgeInsets.symmetric(vertical: 1.v),
                        onTap: () {
                          onTapBack();
                        }),
                    AppbarTitle(
                        text: "lbl_health_profile".tr,
                        margin: EdgeInsets.only(left: 52.h))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildReason() {
    return CustomTextFormField(
        controller: controller.reasonController,
        hintText: "msg_new_health_concern".tr,
        textInputAction: TextInputAction.done,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(26.h, 16.v, 18.h, 16.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgEmergency,
                height: 20.adaptSize,
                width: 20.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 52.v),
        borderDecoration: TextFormFieldStyleHelper.fillDeepOrange,
        fillColor: appTheme.deepOrange50);
  }

  /// Section Widget
  Widget _buildThree() {
    return CustomOutlinedButton(
        height: 56.v,
        width: 62.h,
        text: "lbl_3".tr,
        buttonStyle: CustomButtonStyles.outlinePrimaryContainerTL6,
        buttonTextStyle: CustomTextStyles.titleMediumGray900_1);
  }

  /// Section Widget
  Widget _buildFrameFortySix() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Obx(() => CustomCheckboxButton(
          text: "msg_difficulty_sleeping".tr,
          value: controller.difficultysleeping.value,
          onChange: (value) {
            controller.difficultysleeping.value = value;
          })),
      Obx(() => CustomCheckboxButton(
          text: "msg_fatigue_weakness".tr,
          value: controller.fatigueweakness.value,
          onChange: (value) {
            controller.fatigueweakness.value = value;
          }))
    ]);
  }

  /// Section Widget
  Widget _buildFrameFortySeven() {
    return Padding(
        padding: EdgeInsets.only(right: 29.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(bottom: 1.v),
              child: Obx(() => CustomCheckboxButton(
                  text: "lbl_fever".tr,
                  value: controller.fever.value,
                  onChange: (value) {
                    controller.fever.value = value;
                  }))),
          Obx(() => CustomRadioButton(
              text: "msg_loss_of_appetite".tr,
              value: "msg_loss_of_appetite".tr,
              groupValue: controller.radioGroup.value,
              textStyle: CustomTextStyles.titleMediumBlack90001_1,
              onChange: (value) {
                controller.radioGroup.value = value;
              }))
        ]));
  }

  /// Section Widget
  Widget _buildMoodchanges() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_mood_changes".tr,
        value: controller.moodchanges.value,
        onChange: (value) {
          controller.moodchanges.value = value;
        }));
  }

  /// Section Widget
  Widget _buildNightsweats() {
    return Padding(
        padding: EdgeInsets.only(left: 41.h),
        child: Obx(() => CustomCheckboxButton(
            text: "lbl_night_sweats".tr,
            value: controller.nightsweats.value,
            onChange: (value) {
              controller.nightsweats.value = value;
            })));
  }

  /// Section Widget
  Widget _buildCongestions() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_congestions".tr,
        value: controller.congestions.value,
        onChange: (value) {
          controller.congestions.value = value;
        }));
  }

  /// Section Widget
  Widget _buildEarpain() {
    return Padding(
        padding: EdgeInsets.only(left: 57.h),
        child: Obx(() => CustomCheckboxButton(
            text: "lbl_ear_pain".tr,
            value: controller.earpain.value,
            onChange: (value) {
              controller.earpain.value = value;
            })));
  }

  /// Section Widget
  Widget _buildEyeredness() {
    return Padding(
        padding: EdgeInsets.only(top: 1.v),
        child: Obx(() => CustomCheckboxButton(
            text: "lbl_eye_redness".tr,
            value: controller.eyeredness.value,
            onChange: (value) {
              controller.eyeredness.value = value;
            })));
  }

  /// Section Widget
  Widget _buildHeadaches() {
    return Padding(
        padding: EdgeInsets.only(left: 61.h),
        child: Obx(() => CustomCheckboxButton(
            text: "lbl_headaches".tr,
            value: controller.headaches.value,
            onChange: (value) {
              controller.headaches.value = value;
            })));
  }

  /// Section Widget
  Widget _buildLossofsmell() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_loss_of_smell".tr,
        value: controller.lossofsmell.value,
        onChange: (value) {
          controller.lossofsmell.value = value;
        }));
  }

  /// Section Widget
  Widget _buildLossoftaste() {
    return Obx(() => CustomCheckboxButton(
        text: "lbl_loss_of_taste".tr,
        value: controller.lossoftaste.value,
        onChange: (value) {
          controller.lossoftaste.value = value;
        }));
  }

  /// Section Widget
  Widget _buildInputField() {
    return Padding(
        padding: EdgeInsets.only(right: 6.h),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
              width: 249.h,
              margin: EdgeInsets.only(right: 106.h),
              child: Text("msg_are_you_currently".tr,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.titleMediumGray900
                      .copyWith(height: 1.56))),
          SizedBox(height: 7.v),
          Container(
              width: 327.h,
              margin: EdgeInsets.only(right: 28.h),
              child: Text("msg_please_consider".tr,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleMedium!.copyWith(height: 1.50))),
          SizedBox(height: 16.v),
          Padding(
              padding: EdgeInsets.only(left: 10.h),
              child: Row(children: [
                CustomImageView(
                    imagePath: ImageConstant.imgRadioCheckbox,
                    height: 24.v,
                    width: 30.h),
                Padding(
                    padding: EdgeInsets.only(left: 4.h),
                    child: Text("lbl_yes".tr,
                        style: CustomTextStyles.titleMediumBluegray900)),
                Obx(() => Padding(
                    padding: EdgeInsets.only(left: 123.h),
                    child: CustomRadioButton(
                        text: "lbl_no".tr,
                        value: "lbl_no".tr,
                        groupValue: controller.radioGroup1.value,
                        padding: EdgeInsets.symmetric(vertical: 1.v),
                        onChange: (value) {
                          controller.radioGroup1.value = value;
                        })))
              ])),
          SizedBox(height: 18.v),
          Text("msg_list_medications".tr, style: theme.textTheme.titleMedium),
          SizedBox(height: 19.v),
          Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text("lbl_medication_1".tr,
                  style: CustomTextStyles.titleMediumBluegray80001),
              SizedBox(height: 1.v),
              SizedBox(
                  width: 230.h,
                  child: Divider(color: theme.colorScheme.primaryContainer))
            ]),
            Padding(
                padding: EdgeInsets.only(left: 18.h, top: 2.v),
                child: Text("lbl_how_long".tr,
                    style: CustomTextStyles.titleMediumOnPrimaryContainer)),
            CustomImageView(
                imagePath: ImageConstant.imgIconrightBlueGray70001,
                height: 24.adaptSize,
                width: 24.adaptSize,
                margin: EdgeInsets.only(left: 10.h))
          ]),
          SizedBox(height: 17.v),
          Row(children: [
            CustomImageView(
                imagePath: ImageConstant.imgAddBlueGray80001,
                height: 24.adaptSize,
                width: 24.adaptSize),
            Padding(
                padding: EdgeInsets.only(left: 10.h),
                child: Text("msg_add_new_medication".tr,
                    style: CustomTextStyles.titleMediumBluegray80001))
          ])
        ]));
  }

  /// Section Widget
  Widget _buildContinue() {
    return CustomOutlinedButton(
        text: "lbl_continue".tr,
        onPressed: () {
          onTapContinue();
        });
  }

  /// Section Widget
  Widget _buildInputField1() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Container(
            margin: EdgeInsets.only(bottom: 279.v),
            padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 14.v),
            decoration: AppDecoration.outlineBlack90001,
            child: _buildContinue()));
  }

  /// Navigates to the calendarOneScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.calendarOneScreen,
    );
  }

  /// Navigates to the bookAppointmentOneScreen when the action is triggered.
  onTapContinue() {
    Get.toNamed(
      AppRoutes.bookAppointmentOneScreen,
    );
  }
}
