import '../controller/book_appointment_four_controller.dart';
import '../models/bookappointmentfour_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class BookappointmentfourItemWidget extends StatelessWidget {
  BookappointmentfourItemWidget(
    this.bookappointmentfourItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  BookappointmentfourItemModel bookappointmentfourItemModelObj;

  var controller = Get.find<BookAppointmentFourController>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 13.v,
      ),
      decoration: AppDecoration.fillDeepOrange,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Obx(
            () => CustomIconButton(
              height: 44.adaptSize,
              width: 44.adaptSize,
              padding: EdgeInsets.all(10.h),
              decoration: IconButtonStyleHelper.fillRed,
              child: CustomImageView(
                imagePath: bookappointmentfourItemModelObj.emergency!.value,
              ),
            ),
          ),
          SizedBox(height: 9.v),
          SizedBox(
            width: 87.h,
            child: Obx(
              () => Text(
                bookappointmentfourItemModelObj.newHealthConcern!.value,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: CustomTextStyles.titleMediumGray900_1.copyWith(
                  height: 1.50,
                ),
              ),
            ),
          ),
          SizedBox(height: 24.v),
          Obx(
            () => Text(
              bookappointmentfourItemModelObj.findADoctor!.value,
              style: CustomTextStyles.labelLargeBluegray70002,
            ),
          ),
        ],
      ),
    );
  }
}
