import '../controller/choose_doctor_controller.dart';
import '../models/doctorscloseby_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_rating_bar.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class DoctorsclosebyItemWidget extends StatelessWidget {
  DoctorsclosebyItemWidget(
    this.doctorsclosebyItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  DoctorsclosebyItemModel doctorsclosebyItemModelObj;

  var controller = Get.find<ChooseDoctorController>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 10.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        children: [
          Container(
            height: 40.adaptSize,
            width: 40.adaptSize,
            margin: EdgeInsets.symmetric(vertical: 27.v),
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgRectangle2,
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  radius: BorderRadius.circular(
                    20.h,
                  ),
                  alignment: Alignment.center,
                ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    height: 10.adaptSize,
                    width: 10.adaptSize,
                    decoration: BoxDecoration(
                      color: appTheme.greenA700,
                      borderRadius: BorderRadius.circular(
                        5.h,
                      ),
                      border: Border.all(
                        color: appTheme.gray100,
                        width: 1.h,
                        strokeAlign: strokeAlignOutside,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 10.h,
              top: 2.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "msg_general_physician".tr,
                  style: theme.textTheme.titleSmall,
                ),
                SizedBox(height: 2.v),
                Text(
                  "msg_dr_jose_manavalan".tr,
                  style: CustomTextStyles.titleMediumBluegray90001,
                ),
                SizedBox(height: 4.v),
                SizedBox(
                  width: 213.h,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomRatingBar(
                        ignoreGestures: true,
                        initialRating: 0,
                      ),
                      Text(
                        "lbl_1031_ratings".tr,
                        style: theme.textTheme.titleSmall,
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 4.v),
                Text(
                  "msg_silver_crest_hospital".tr,
                  style: theme.textTheme.titleSmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
