import 'controller/login_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/core/utils/validation_functions.dart';
import 'package:eric_s_application2/widgets/custom_checkbox_button.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:eric_s_application2/domain/googleauth/google_auth_helper.dart';

// ignore_for_file: must_be_immutable
class LoginScreen extends GetWidget<LoginController> {
  LoginScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 16.h, vertical: 56.v),
                    child: Column(children: [
                      Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("lbl_maanvric".tr,
                                style: CustomTextStyles.headlineSmallPrimary_1),
                            CustomImageView(
                                imagePath: ImageConstant.imgBeatingheart,
                                height: 31.v,
                                width: 33.h)
                          ]),
                      SizedBox(height: 24.v),
                      Text("msg_sign_in_to_your".tr,
                          style: theme.textTheme.headlineSmall),
                      SizedBox(height: 8.v),
                      Text("msg_welcome_back_you".tr,
                          style: theme.textTheme.titleMedium),
                      SizedBox(height: 34.v),
                      _buildInputWithLabel(),
                      SizedBox(height: 20.v),
                      _buildInputWithLabel1(),
                      SizedBox(height: 40.v),
                      _buildActionsRow(),
                      SizedBox(height: 36.v),
                      _buildSignIn(),
                      SizedBox(height: 25.v),
                      _buildDivide(),
                      SizedBox(height: 24.v),
                      _buildSignInWithGoogle(),
                      SizedBox(height: 41.v),
                      RichText(
                          text: TextSpan(children: [
                            TextSpan(
                                text: "msg_don_t_have_an_account2".tr,
                                style: theme.textTheme.titleMedium),
                            TextSpan(
                                text: "lbl_sign_up".tr,
                                style: CustomTextStyles.titleMediumPrimary_1)
                          ]),
                          textAlign: TextAlign.left),
                      SizedBox(height: 5.v)
                    ])))));
  }

  /// Section Widget
  Widget _buildEmail() {
    return CustomTextFormField(
        controller: controller.emailController,
        hintText: "msg_example_email_com".tr,
        textInputType: TextInputType.emailAddress,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgMail,
                height: 20.adaptSize,
                width: 20.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        validator: (value) {
          if (value == null || (!isValidEmail(value, isRequired: true))) {
            return "err_msg_please_enter_valid_email".tr;
          }
          return null;
        });
  }

  /// Section Widget
  Widget _buildInputWithLabel() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text("lbl_email".tr, style: CustomTextStyles.titleSmallBluegray80001),
      SizedBox(height: 6.v),
      _buildEmail()
    ]);
  }

  /// Section Widget
  Widget _buildPassword() {
    return Obx(() => CustomTextFormField(
        controller: controller.passwordController,
        hintText: "msg_enter_your_password".tr,
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgUnlock,
                height: 20.adaptSize,
                width: 20.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        suffix: InkWell(
            onTap: () {
              controller.isShowPassword.value =
                  !controller.isShowPassword.value;
            },
            child: Container(
                margin: EdgeInsets.fromLTRB(12.h, 18.v, 14.h, 18.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgEye,
                    height: 20.adaptSize,
                    width: 20.adaptSize))),
        suffixConstraints: BoxConstraints(maxHeight: 56.v),
        validator: (value) {
          if (value == null || (!isValidPassword(value, isRequired: true))) {
            return "err_msg_please_enter_valid_password".tr;
          }
          return null;
        },
        obscureText: controller.isShowPassword.value,
        contentPadding: EdgeInsets.symmetric(vertical: 15.v)));
  }

  /// Section Widget
  Widget _buildInputWithLabel1() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text("lbl_password".tr, style: CustomTextStyles.titleSmallBluegray80001),
      SizedBox(height: 6.v),
      _buildPassword()
    ]);
  }

  /// Section Widget
  Widget _buildActionsRow() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Obx(() => CustomCheckboxButton(
          text: "msg_remember_for_30".tr,
          value: controller.rememberfordays.value,
          textStyle: CustomTextStyles.titleSmallBluegray80001,
          onChange: (value) {
            controller.rememberfordays.value = value;
          })),
      Text("msg_forgot_password".tr, style: CustomTextStyles.titleSmallOnError)
    ]);
  }

  /// Section Widget
  Widget _buildSignIn() {
    return CustomOutlinedButton(text: "lbl_sign_in".tr);
  }

  /// Section Widget
  Widget _buildDivide() {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
              padding: EdgeInsets.only(top: 9.v, bottom: 10.v),
              child: SizedBox(
                  width: 116.h, child: Divider(color: appTheme.blueGray5001))),
          Text("lbl_or_sign_in_with".tr, style: theme.textTheme.titleMedium),
          Padding(
              padding: EdgeInsets.only(top: 9.v, bottom: 10.v),
              child: SizedBox(
                  width: 116.h, child: Divider(color: appTheme.blueGray5001)))
        ]);
  }

  /// Section Widget
  Widget _buildSignInWithGoogle() {
    return CustomOutlinedButton(
        text: "msg_sign_in_with_google".tr,
        leftIcon: Container(
            margin: EdgeInsets.only(right: 12.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgSocialIcon,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        buttonStyle: CustomButtonStyles.outlinePrimaryContainer,
        buttonTextStyle: CustomTextStyles.titleMediumBluegray80001,
        onPressed: () {
          onTapSignInWithGoogle();
        });
  }

  onTapSignInWithGoogle() async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        //TODO Actions to be performed after signin
      } else {
        Get.snackbar('Error', 'user data is empty');
      }
    }).catchError((onError) {
      Get.snackbar('Error', onError.toString());
    });
  }
}
