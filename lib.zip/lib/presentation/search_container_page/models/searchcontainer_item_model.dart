import '../../../core/app_export.dart';

/// This class is used in the [searchcontainer_item_widget] screen.
class SearchcontainerItemModel {
  SearchcontainerItemModel({
    this.event,
    this.bookAnAppointment,
    this.findADoctor,
    this.id,
  }) {
    event = event ?? Rx(ImageConstant.imgEvent);
    bookAnAppointment = bookAnAppointment ?? Rx("Book an Appointment");
    findADoctor = findADoctor ?? Rx("Find a Doctor");
    id = id ?? Rx("");
  }

  Rx<String>? event;

  Rx<String>? bookAnAppointment;

  Rx<String>? findADoctor;

  Rx<String>? id;
}
