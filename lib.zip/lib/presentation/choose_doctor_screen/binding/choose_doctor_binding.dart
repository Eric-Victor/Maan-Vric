import '../controller/choose_doctor_controller.dart';
import 'package:get/get.dart';

/// A binding class for the ChooseDoctorScreen.
///
/// This class ensures that the ChooseDoctorController is created when the
/// ChooseDoctorScreen is first loaded.
class ChooseDoctorBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ChooseDoctorController());
  }
}
