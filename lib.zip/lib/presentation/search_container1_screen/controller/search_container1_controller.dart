import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container1_screen/models/search_container1_model.dart';

/// A controller class for the SearchContainer1Screen.
///
/// This class manages the state of the SearchContainer1Screen, including the
/// current searchContainer1ModelObj
class SearchContainer1Controller extends GetxController {
  Rx<SearchContainer1Model> searchContainer1ModelObj =
      SearchContainer1Model().obs;
}
