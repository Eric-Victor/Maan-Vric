import '../../../core/app_export.dart';
import 'bookappointmentfour_item_model.dart';

/// This class defines the variables used in the [book_appointment_four_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class BookAppointmentFourModel {
  Rx<List<BookappointmentfourItemModel>> bookappointmentfourItemList = Rx([
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgEmergency.obs,
        newHealthConcern: "New Health Concern".obs,
        findADoctor: "Find a Doctor".obs),
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgVerified.obs,
        newHealthConcern: "Routine checkup, Follow-up or Screening".obs,
        findADoctor: "Find a Doctor".obs),
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgKingBed.obs,
        newHealthConcern: "Existing or Chronic condition".obs,
        findADoctor: "Talk to a Specialist".obs),
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgMedication.obs,
        newHealthConcern: "Prescriptions or Refills".obs,
        findADoctor: "Talk to a Pharmacist".obs),
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgTheaterComedy.obs,
        newHealthConcern: "General Mental Health Concerns".obs,
        findADoctor: "Find a Doctor".obs),
    BookappointmentfourItemModel(
        emergency: ImageConstant.imgCoronavirus.obs,
        newHealthConcern: "COVID-19 Symptoms".obs,
        findADoctor: "Find a Doctor".obs)
  ]);
}
