import '../controller/book_appointment_three_controller.dart';
import 'package:get/get.dart';

/// A binding class for the BookAppointmentThreeScreen.
///
/// This class ensures that the BookAppointmentThreeController is created when the
/// BookAppointmentThreeScreen is first loaded.
class BookAppointmentThreeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BookAppointmentThreeController());
  }
}
