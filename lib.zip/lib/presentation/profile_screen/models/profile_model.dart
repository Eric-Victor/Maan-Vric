import '../../../core/app_export.dart';
import 'profile_item_model.dart';

/// This class defines the variables used in the [profile_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ProfileModel {
  Rx<List<ProfileItemModel>> profileItemList = Rx([
    ProfileItemModel(
        settings: ImageConstant.imgSettings.obs,
        settings1: "Settings".obs,
        description: "Configure tyour account your way".obs),
    ProfileItemModel(
        settings: ImageConstant.imgNotListedLocation.obs,
        settings1: "Help & Support".obs,
        description: "24/7 customer support".obs),
    ProfileItemModel(
        settings: ImageConstant.imgLogout.obs,
        settings1: "Log Out".obs,
        description: "Securely Logout of the site.".obs)
  ]);
}
