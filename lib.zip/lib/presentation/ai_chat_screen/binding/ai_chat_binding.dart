import '../controller/ai_chat_controller.dart';
import 'package:get/get.dart';

/// A binding class for the AiChatScreen.
///
/// This class ensures that the AiChatController is created when the
/// AiChatScreen is first loaded.
class AiChatBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AiChatController());
  }
}
