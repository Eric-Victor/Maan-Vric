import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/book_appointment_screen/models/book_appointment_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the BookAppointmentScreen.
///
/// This class manages the state of the BookAppointmentScreen, including the
/// current bookAppointmentModelObj
class BookAppointmentController extends GetxController {
  TextEditingController addController = TextEditingController();

  TextEditingController inputFieldController = TextEditingController();

  TextEditingController nameController = TextEditingController();

  TextEditingController cardNumberController = TextEditingController();

  TextEditingController inputController = TextEditingController();

  TextEditingController cvvController = TextEditingController();

  Rx<BookAppointmentModel> bookAppointmentModelObj = BookAppointmentModel().obs;

  @override
  void onClose() {
    super.onClose();
    addController.dispose();
    inputFieldController.dispose();
    nameController.dispose();
    cardNumberController.dispose();
    inputController.dispose();
    cvvController.dispose();
  }
}
