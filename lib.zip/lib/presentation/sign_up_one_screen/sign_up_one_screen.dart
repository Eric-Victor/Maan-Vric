import 'controller/sign_up_one_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_search_view.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class SignUpOneScreen extends GetWidget<SignUpOneController> {
  const SignUpOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 49.v,
          ),
          child: Column(
            children: [
              Text(
                "msg_health_insurance".tr,
                style: theme.textTheme.headlineSmall,
              ),
              SizedBox(height: 11.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 342.h,
                  margin: EdgeInsets.only(right: 15.h),
                  child: Text(
                    "msg_search_for_your".tr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleMedium!.copyWith(
                      height: 1.50,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 8.v),
              CustomImageView(
                imagePath: ImageConstant.imgProgressbarBlueGray50,
                height: 3.v,
                width: 358.h,
                radius: BorderRadius.circular(
                  1.h,
                ),
              ),
              SizedBox(height: 56.v),
              _buildInputField(),
              Spacer(),
              CustomOutlinedButton(
                text: "lbl_save".tr,
              ),
              SizedBox(height: 16.v),
              CustomOutlinedButton(
                text: "lbl_skip_insurance".tr,
                buttonStyle: CustomButtonStyles.outlinePrimaryContainer,
                buttonTextStyle: CustomTextStyles.titleMediumInterGray900,
              ),
              SizedBox(height: 16.v),
              Text(
                "msg_you_can_see_a_doctor".tr,
                style: theme.textTheme.titleMedium,
              ),
              SizedBox(height: 28.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildInputField() {
    return Column(
      children: [
        CustomSearchView(
          controller: controller.searchController,
          hintText: "lbl_search".tr,
        ),
        SizedBox(height: 18.v),
        Text(
          "msg_e_g_star_insurance".tr,
          style: CustomTextStyles.titleMediumBlack90001_1,
        ),
      ],
    );
  }
}
