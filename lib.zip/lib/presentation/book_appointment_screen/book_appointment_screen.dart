import '../book_appointment_screen/widgets/payment_item_widget.dart';
import 'controller/book_appointment_controller.dart';
import 'models/payment_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/core/utils/validation_functions.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button_one.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class BookAppointmentScreen extends GetWidget<BookAppointmentController> {
  BookAppointmentScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      _buildTopNavigation(),
                      Expanded(
                          child: SingleChildScrollView(
                              child: Padding(
                                  padding: EdgeInsets.only(bottom: 5.v),
                                  child: Column(children: [
                                    Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 15.h, vertical: 24.v),
                                        decoration: AppDecoration.fillOnPrimary,
                                        child: Column(children: [
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                  width: 342.h,
                                                  margin: EdgeInsets.only(
                                                      right: 15.h),
                                                  child: Text(
                                                      "msg_make_payment_to".tr,
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: theme.textTheme
                                                          .titleMedium!
                                                          .copyWith(
                                                              height: 1.50)))),
                                          SizedBox(height: 8.v),
                                          CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgProgressbarGreenA700,
                                              height: 3.v,
                                              width: 358.h),
                                          SizedBox(height: 40.v),
                                          _buildDoctor1(),
                                          SizedBox(height: 16.v),
                                          Divider(),
                                          SizedBox(height: 32.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  "lbl_order_summary".tr,
                                                  style: theme
                                                      .textTheme.titleMedium)),
                                          SizedBox(height: 17.v),
                                          _buildFrame(),
                                          SizedBox(height: 16.v),
                                          _buildFrame1(),
                                          SizedBox(height: 32.v),
                                          Divider(),
                                          SizedBox(height: 33.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  "msg_use_health_insurance".tr,
                                                  style: CustomTextStyles
                                                      .titleMediumGray900)),
                                          SizedBox(height: 18.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                  width: 298.h,
                                                  margin: EdgeInsets.only(
                                                      right: 59.h),
                                                  child: Text(
                                                      "msg_add_your_insurance"
                                                          .tr,
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: theme.textTheme
                                                          .titleMedium!
                                                          .copyWith(
                                                              height: 1.50)))),
                                          SizedBox(height: 14.v),
                                          _buildAdd(),
                                          SizedBox(height: 32.v),
                                          Divider(),
                                          SizedBox(height: 35.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  "msg_select_payment_method"
                                                      .tr,
                                                  style: CustomTextStyles
                                                      .titleMediumBlack90001_1)),
                                          SizedBox(height: 25.v),
                                          _buildInputField(),
                                          SizedBox(height: 24.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  "msg_card_holders_name".tr,
                                                  style: CustomTextStyles
                                                      .titleSmallBluegray80001)),
                                          SizedBox(height: 6.v),
                                          _buildName(),
                                          SizedBox(height: 20.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text("lbl_card_numbers".tr,
                                                  style: CustomTextStyles
                                                      .titleSmallBluegray80001)),
                                          SizedBox(height: 6.v),
                                          _buildCardNumber(),
                                          SizedBox(height: 20.v),
                                          _buildFrame2(),
                                          SizedBox(height: 40.v),
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                  "lbl_other_services".tr,
                                                  style: CustomTextStyles
                                                      .titleMediumBlack90001_1)),
                                          SizedBox(height: 11.v),
                                          _buildPayment(),
                                          SizedBox(height: 6.v)
                                        ])),
                                    SizedBox(height: 34.v),
                                    _buildInputField1()
                                  ]))))
                    ])))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              title: Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Row(children: [
                    AppbarTitleButtonOne(
                        margin: EdgeInsets.symmetric(vertical: 1.v),
                        onTap: () {
                          onTapBack();
                        }),
                    AppbarTitle(
                        text: "lbl_rahul_s_visit".tr,
                        margin: EdgeInsets.only(left: 58.h))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildDoctor1() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 15.v),
        decoration: AppDecoration.fillOnPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(children: [
          Container(
              height: 40.adaptSize,
              width: 40.adaptSize,
              margin: EdgeInsets.symmetric(vertical: 29.v),
              child: Stack(alignment: Alignment.bottomRight, children: [
                CustomImageView(
                    imagePath: ImageConstant.imgRectangle27,
                    height: 40.adaptSize,
                    width: 40.adaptSize,
                    radius: BorderRadius.circular(20.h),
                    alignment: Alignment.center),
                Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                        height: 10.adaptSize,
                        width: 10.adaptSize,
                        decoration: BoxDecoration(
                            color: appTheme.greenA700,
                            borderRadius: BorderRadius.circular(5.h),
                            border: Border.all(
                                color: appTheme.gray100,
                                width: 1.h,
                                strokeAlign: strokeAlignOutside))))
              ])),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(left: 10.h),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            width: 128.h,
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.h, vertical: 2.v),
                            decoration: AppDecoration.fillBlue50.copyWith(
                                borderRadius: BorderRadiusStyle.circleBorder11),
                            child: Text("msg_video_consultation2".tr,
                                style: CustomTextStyles.labelLargeIndigo500)),
                        SizedBox(height: 3.v),
                        Text("msg_dr_jose_manavalan".tr,
                            style: CustomTextStyles.titleMediumBluegray90001),
                        SizedBox(height: 6.v),
                        Text("msg_general_physician2".tr,
                            style: theme.textTheme.titleSmall),
                        SizedBox(height: 3.v),
                        RichText(
                            text: TextSpan(children: [
                              TextSpan(
                                  text: "lbl_today_12_30pm".tr,
                                  style: CustomTextStyles
                                      .titleMediumBluegray90001_1),
                              TextSpan(
                                  text: "lbl_30mins".tr,
                                  style: theme.textTheme.titleMedium)
                            ]),
                            textAlign: TextAlign.left)
                      ])))
        ]));
  }

  /// Section Widget
  Widget _buildFrame() {
    return Container(
        decoration: AppDecoration.fillGray
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(height: 14.v),
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 11.h),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadiusStyle.roundedBorder8),
                  child: Column(children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 40.v,
                                    width: 173.h,
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.topCenter,
                                              child: Text(
                                                  "msg_primary_care_visit".tr,
                                                  style: CustomTextStyles
                                                      .titleMediumBluegray90001)),
                                          Align(
                                              alignment: Alignment.bottomCenter,
                                              child: Text(
                                                  "msg_with_dr_jose_manavalan"
                                                      .tr,
                                                  style: theme
                                                      .textTheme.titleSmall))
                                        ])),
                                SizedBox(height: 1.v),
                                SizedBox(
                                    width: 226.h,
                                    child: Text("msg_22nd_wed_june".tr,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.titleSmall!
                                            .copyWith(height: 1.43)))
                              ]),
                          Padding(
                              padding: EdgeInsets.only(bottom: 59.v),
                              child: Text("lbl_5_700".tr,
                                  style: CustomTextStyles.titleMediumGray900_1))
                        ]),
                    SizedBox(height: 14.v),
                    Divider()
                  ])),
              SizedBox(height: 19.v),
              Container(
                  margin: EdgeInsets.symmetric(horizontal: 11.h),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadiusStyle.roundedBorder8),
                  child: Column(children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                              padding: EdgeInsets.only(bottom: 1.v),
                              child: Text("lbl_discount".tr,
                                  style: CustomTextStyles
                                      .titleMediumBluegray90001)),
                          Text("lbl_0_00".tr,
                              style: theme.textTheme.titleMedium)
                        ]),
                    SizedBox(height: 17.v),
                    Divider()
                  ])),
              SizedBox(height: 14.v),
              Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.h, vertical: 14.v),
                  decoration: AppDecoration.fillPrimary.copyWith(
                      borderRadius: BorderRadiusStyle.customBorderBL6),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("lbl_today_s_total".tr,
                            style: CustomTextStyles.titleMediumGray50),
                        Text("lbl_5_700".tr,
                            style: CustomTextStyles.titleMediumGray50)
                      ]))
            ]));
  }

  /// Section Widget
  Widget _buildFrame1() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 16.v),
        decoration: AppDecoration.fillOnPrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
        child: Row(children: [
          CustomImageView(
              imagePath: ImageConstant.imgAddPrimary,
              height: 24.adaptSize,
              width: 24.adaptSize),
          Padding(
              padding: EdgeInsets.only(left: 10.h, top: 2.v, bottom: 2.v),
              child: Text("lbl_add_promo_code".tr,
                  style: CustomTextStyles.titleSmallPrimary))
        ]));
  }

  /// Section Widget
  Widget _buildAdd() {
    return CustomTextFormField(
        width: 146.h,
        controller: controller.addController,
        hintText: "lbl_add_insurance".tr,
        hintStyle: CustomTextStyles.titleMediumPrimary,
        alignment: Alignment.centerLeft,
        prefix: Container(
            margin: EdgeInsets.only(right: 10.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgAddPrimary,
                height: 24.adaptSize,
                width: 24.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 24.v),
        contentPadding: EdgeInsets.symmetric(vertical: 1.v));
  }

  /// Section Widget
  Widget _buildInputField() {
    return CustomTextFormField(
        controller: controller.inputFieldController,
        hintText: "msg_credit_crad_debit".tr,
        hintStyle: CustomTextStyles.titleMediumBluegray900,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 13.v, 4.h, 13.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgRadioCheckbox,
                height: 30.adaptSize,
                width: 30.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v));
  }

  /// Section Widget
  Widget _buildName() {
    return CustomTextFormField(
        controller: controller.nameController,
        hintText: "msg_card_holders_name2".tr,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgAccountcircleBlueGray500,
                height: 20.adaptSize,
                width: 20.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        validator: (value) {
          if (!isText(value)) {
            return "err_msg_please_enter_valid_text".tr;
          }
          return null;
        });
  }

  /// Section Widget
  Widget _buildCardNumber() {
    return CustomTextFormField(
        controller: controller.cardNumberController,
        hintText: "msg_0000_0000_0000".tr,
        prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgCreditcard,
                height: 20.adaptSize,
                width: 20.adaptSize)),
        prefixConstraints: BoxConstraints(maxHeight: 56.v),
        suffix: Container(
            margin: EdgeInsets.fromLTRB(30.h, 20.v, 14.h, 20.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgHelpIcon,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        suffixConstraints: BoxConstraints(maxHeight: 56.v),
        contentPadding: EdgeInsets.symmetric(vertical: 17.v));
  }

  /// Section Widget
  Widget _buildInput() {
    return CustomTextFormField(
        width: 171.h,
        controller: controller.inputController,
        hintText: "lbl_mm_yy".tr,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(30.h, 20.v, 14.h, 20.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgHelpIcon,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        suffixConstraints: BoxConstraints(maxHeight: 56.v),
        contentPadding: EdgeInsets.only(left: 14.h, top: 17.v, bottom: 17.v));
  }

  /// Section Widget
  Widget _buildCvv() {
    return CustomTextFormField(
        width: 171.h,
        controller: controller.cvvController,
        hintText: "lbl_xxx".tr,
        textInputAction: TextInputAction.done,
        suffix: Container(
            margin: EdgeInsets.fromLTRB(30.h, 20.v, 14.h, 20.v),
            child: CustomImageView(
                imagePath: ImageConstant.imgHelpIcon,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        suffixConstraints: BoxConstraints(maxHeight: 56.v),
        contentPadding: EdgeInsets.only(left: 14.h, top: 17.v, bottom: 17.v));
  }

  /// Section Widget
  Widget _buildFrame2() {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Expanded(
          child: Padding(
              padding: EdgeInsets.only(top: 1.v, right: 8.h),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("msg_card_expiriation".tr,
                        style: CustomTextStyles.titleSmallBluegray80001),
                    SizedBox(height: 5.v),
                    _buildInput()
                  ]))),
      Expanded(
          child: Padding(
              padding: EdgeInsets.only(left: 8.h),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("lbl_cvv".tr,
                        style: CustomTextStyles.titleSmallBluegray80001),
                    SizedBox(height: 6.v),
                    _buildCvv()
                  ])))
    ]);
  }

  /// Section Widget
  Widget _buildPayment() {
    return Obx(() => Wrap(
        runSpacing: 29.v,
        spacing: 29.h,
        children: List<Widget>.generate(
            controller.bookAppointmentModelObj.value.paymentItemList.value
                .length, (index) {
          PaymentItemModel model = controller
              .bookAppointmentModelObj.value.paymentItemList.value[index];
          return PaymentItemWidget(model);
        })));
  }

  /// Section Widget
  Widget _buildInputField1() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        decoration: AppDecoration.outlineBlack90001,
        child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(height: 21.v),
              Container(
                  decoration: AppDecoration.fillGreenA
                      .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
                  child: GestureDetector(
                      onTap: () {
                        onTapFrameSixtyFour();
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 119.h),
                          decoration: AppDecoration.outlineGreenA.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder8),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Padding(
                                    padding: EdgeInsets.only(top: 14.v),
                                    child: Text("lbl_pay_5_700".tr,
                                        style: CustomTextStyles
                                            .titleMediumOnPrimary)),
                                CustomImageView(
                                    imagePath: ImageConstant.imgArrowright,
                                    height: 14.v,
                                    width: 24.h,
                                    margin: EdgeInsets.only(top: 12.v))
                              ]))))
            ]));
  }

  /// Navigates to the bookAppointmentTwoScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.bookAppointmentTwoScreen,
    );
  }

  /// Navigates to the popUpScreen when the action is triggered.
  onTapFrameSixtyFour() {
    Get.toNamed(
      AppRoutes.popUpScreen,
    );
  }
}
