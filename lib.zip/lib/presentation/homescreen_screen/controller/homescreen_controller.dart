import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/homescreen_screen/models/homescreen_model.dart';

/// A controller class for the HomescreenScreen.
///
/// This class manages the state of the HomescreenScreen, including the
/// current homescreenModelObj
class HomescreenController extends GetxController {
  Rx<HomescreenModel> homescreenModelObj = HomescreenModel().obs;

  @override
  void onReady() {
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.offNamed(
        AppRoutes.onboardingOneScreen,
      );
    });
  }
}
