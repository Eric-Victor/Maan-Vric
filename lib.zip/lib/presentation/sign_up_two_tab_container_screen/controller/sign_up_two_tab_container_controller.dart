import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/sign_up_two_tab_container_screen/models/sign_up_two_tab_container_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the SignUpTwoTabContainerScreen.
///
/// This class manages the state of the SignUpTwoTabContainerScreen, including the
/// current signUpTwoTabContainerModelObj
class SignUpTwoTabContainerController extends GetxController
    with GetSingleTickerProviderStateMixin {
  TextEditingController firstNameController = TextEditingController();

  TextEditingController lastNameController = TextEditingController();

  Rx<SignUpTwoTabContainerModel> signUpTwoTabContainerModelObj =
      SignUpTwoTabContainerModel().obs;

  late TabController tabviewController =
      Get.put(TabController(vsync: this, length: 2));

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  @override
  void onClose() {
    super.onClose();
    firstNameController.dispose();
    lastNameController.dispose();
  }

  onSelected(dynamic value) {
    for (var element
        in signUpTwoTabContainerModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    signUpTwoTabContainerModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element
        in signUpTwoTabContainerModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    signUpTwoTabContainerModelObj.value.dropdownItemList1.refresh();
  }
}
