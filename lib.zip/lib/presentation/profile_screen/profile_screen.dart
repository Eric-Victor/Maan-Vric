import '../profile_screen/widgets/profile_item_widget.dart';
import 'controller/profile_controller.dart';
import 'models/profile_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container_page/search_container_page.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_bottom_bar.dart';
import 'package:eric_s_application2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class ProfileScreen extends GetWidget<ProfileController> {
  const ProfileScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildTopNavigation(),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    margin: EdgeInsets.only(bottom: 5.v),
                    padding: EdgeInsets.symmetric(
                      horizontal: 16.h,
                      vertical: 25.v,
                    ),
                    decoration: AppDecoration.fillOnPrimary,
                    child: Column(
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "lbl_account".tr,
                            style: CustomTextStyles.titleMediumGray900,
                          ),
                        ),
                        SizedBox(height: 17.v),
                        _buildOpenPeepsAvatar(),
                        SizedBox(height: 35.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "lbl_payment".tr,
                            style: CustomTextStyles.titleMediumGray900,
                          ),
                        ),
                        SizedBox(height: 15.v),
                        _buildDoctor1(),
                        SizedBox(height: 16.v),
                        Divider(),
                        SizedBox(height: 16.v),
                        _buildDoctor2(),
                        SizedBox(height: 34.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "lbl_settings".tr,
                            style: CustomTextStyles.titleMediumGray900,
                          ),
                        ),
                        SizedBox(height: 16.v),
                        _buildProfile(),
                        SizedBox(height: 22.v),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(),
      ),
    );
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 14.v),
      decoration: AppDecoration.outlineBlack,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 8.v),
          CustomAppBar(
            centerTitle: true,
            title: AppbarTitle(
              text: "lbl_profile".tr,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildOpenPeepsAvatar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Container(
            margin: EdgeInsets.only(bottom: 79.v),
            decoration: AppDecoration.fillOnPrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder8,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 45.adaptSize,
                  width: 45.adaptSize,
                  decoration: AppDecoration.outlineBlack900012.copyWith(
                    borderRadius: BorderRadiusStyle.circleBorder22,
                  ),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgOpenPeepsAvatar,
                    height: 45.adaptSize,
                    width: 45.adaptSize,
                    radius: BorderRadius.only(
                      topLeft: Radius.circular(23.h),
                      topRight: Radius.circular(22.h),
                      bottomLeft: Radius.circular(23.h),
                      bottomRight: Radius.circular(22.h),
                    ),
                    alignment: Alignment.center,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 16.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "lbl_rahul_menon".tr,
                        style: CustomTextStyles.titleMediumBluegray90001,
                      ),
                      SizedBox(height: 6.v),
                      Text(
                        "msg_male_27_years_old".tr,
                        style: theme.textTheme.titleSmall,
                      ),
                    ],
                  ),
                ),
                Spacer(),
                CustomImageView(
                  imagePath: ImageConstant.imgBorderColor,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                  margin: EdgeInsets.symmetric(vertical: 11.v),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 62.v),
            child: Divider(),
          ),
        ),
        Expanded(
          child: Container(
            margin: EdgeInsets.only(top: 79.v),
            decoration: AppDecoration.fillOnPrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder8,
            ),
            child: Row(
              children: [
                Container(
                  height: 45.adaptSize,
                  width: 45.adaptSize,
                  margin: EdgeInsets.only(bottom: 1.v),
                  decoration: AppDecoration.fillGray50.copyWith(
                    borderRadius: BorderRadiusStyle.circleBorder22,
                  ),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgHealthiconsPat,
                    height: 45.adaptSize,
                    width: 45.adaptSize,
                    radius: BorderRadius.circular(
                      22.h,
                    ),
                    alignment: Alignment.center,
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: 16.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "lbl_mi_band_4".tr,
                          style: CustomTextStyles.titleMediumBluegray90001,
                        ),
                        SizedBox(height: 5.v),
                        Text(
                          "msg_heart_rate".tr,
                          style: theme.textTheme.titleSmall,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildDoctor1() {
    return Container(
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        children: [
          CustomIconButton(
            height: 45.adaptSize,
            width: 45.adaptSize,
            padding: EdgeInsets.all(8.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgCreditCardBlue600,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "msg_payment_method_on".tr,
                  style: CustomTextStyles.titleMediumBluegray90001,
                ),
                SizedBox(height: 3.v),
                Text(
                  "msg_mastercard_8976".tr,
                  style: CustomTextStyles.titleSmallBlue600,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDoctor2() {
    return Container(
      decoration: AppDecoration.fillOnPrimary.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        children: [
          CustomIconButton(
            height: 45.adaptSize,
            width: 45.adaptSize,
            padding: EdgeInsets.all(8.h),
            decoration: IconButtonStyleHelper.fillTealTL20,
            child: CustomImageView(
              imagePath: ImageConstant.imgReceipt,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 15.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "lbl_transactios".tr,
                  style: CustomTextStyles.titleMediumBluegray90001,
                ),
                SizedBox(height: 5.v),
                Text(
                  "lbl_view".tr,
                  style: CustomTextStyles.titleSmallBlue600,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildProfile() {
    return Obx(
      () => ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0.v),
            child: SizedBox(
              width: 358.h,
              child: Divider(
                height: 1.v,
                thickness: 1.v,
                color: appTheme.blueGray5001,
              ),
            ),
          );
        },
        itemCount:
            controller.profileModelObj.value.profileItemList.value.length,
        itemBuilder: (context, index) {
          ProfileItemModel model =
              controller.profileModelObj.value.profileItemList.value[index];
          return ProfileItemWidget(
            model,
          );
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar() {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Get.toNamed(getCurrentRoute(type), id: 1);
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.searchContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Message:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.searchContainerPage:
        return SearchContainerPage();
      default:
        return DefaultWidget();
    }
  }
}
