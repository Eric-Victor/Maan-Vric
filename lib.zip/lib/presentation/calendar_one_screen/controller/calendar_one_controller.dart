import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/calendar_one_screen/models/calendar_one_model.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:flutter/material.dart';

/// A controller class for the CalendarOneScreen.
///
/// This class manages the state of the CalendarOneScreen, including the
/// current calendarOneModelObj
class CalendarOneController extends GetxController with CodeAutoFill {
  TextEditingController vuesaxlineartextalignjustifyriController =
      TextEditingController();

  TextEditingController addController = TextEditingController();

  Rx<TextEditingController> otpController = TextEditingController().obs;

  Rx<CalendarOneModel> calendarOneModelObj = CalendarOneModel().obs;

  @override
  void codeUpdated() {
    otpController.value.text = code ?? '';
  }

  @override
  void onInit() {
    super.onInit();
    listenForCode();
  }

  @override
  void onClose() {
    super.onClose();
    vuesaxlineartextalignjustifyriController.dispose();
    addController.dispose();
  }
}
