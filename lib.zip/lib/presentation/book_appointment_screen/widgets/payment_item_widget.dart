import '../models/payment_item_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class PaymentItemWidget extends StatelessWidget {
  PaymentItemWidget(
    this.paymentItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  PaymentItemModel paymentItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => RawChip(
        padding: EdgeInsets.only(
          top: 11.v,
          right: 21.h,
          bottom: 11.v,
        ),
        showCheckmark: false,
        labelPadding: EdgeInsets.zero,
        label: Text(
          paymentItemModelObj.inputField!.value,
          style: TextStyle(
            color: appTheme.blueGray80001,
            fontSize: 16.fSize,
            fontFamily: 'GT Walsheim Pro',
            fontWeight: FontWeight.w700,
          ),
        ),
        avatar: CustomImageView(
          imagePath: ImageConstant.imgPaypal,
          height: 17.v,
          width: 14.h,
          margin: EdgeInsets.only(right: 12.h),
        ),
        selected: (paymentItemModelObj.isSelected?.value ?? false),
        backgroundColor: theme.colorScheme.onPrimary.withOpacity(1),
        selectedColor: theme.colorScheme.onPrimary.withOpacity(1),
        shape: (paymentItemModelObj.isSelected?.value ?? false)
            ? RoundedRectangleBorder(
                side: BorderSide(
                  color: theme.colorScheme.onPrimary,
                  width: 1.h,
                ),
                borderRadius: BorderRadius.circular(
                  22.h,
                ),
              )
            : RoundedRectangleBorder(
                side: BorderSide(
                  color: theme.colorScheme.primaryContainer,
                  width: 1.h,
                ),
                borderRadius: BorderRadius.circular(
                  22.h,
                ),
              ),
        onSelected: (value) {
          paymentItemModelObj.isSelected!.value = value;
        },
      ),
    );
  }
}
