import 'package:eric_s_application2/presentation/homescreen_screen/homescreen_screen.dart';
import 'package:eric_s_application2/presentation/homescreen_screen/binding/homescreen_binding.dart';
import 'package:eric_s_application2/presentation/onboarding_one_screen/onboarding_one_screen.dart';
import 'package:eric_s_application2/presentation/onboarding_one_screen/binding/onboarding_one_binding.dart';
import 'package:eric_s_application2/presentation/login_screen/login_screen.dart';
import 'package:eric_s_application2/presentation/login_screen/binding/login_binding.dart';
import 'package:eric_s_application2/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:eric_s_application2/presentation/sign_up_screen/binding/sign_up_binding.dart';
import 'package:eric_s_application2/presentation/sign_up_two_tab_container_screen/sign_up_two_tab_container_screen.dart';
import 'package:eric_s_application2/presentation/sign_up_two_tab_container_screen/binding/sign_up_two_tab_container_binding.dart';
import 'package:eric_s_application2/presentation/sign_up_one_screen/sign_up_one_screen.dart';
import 'package:eric_s_application2/presentation/sign_up_one_screen/binding/sign_up_one_binding.dart';
import 'package:eric_s_application2/presentation/home_screen/home_screen.dart';
import 'package:eric_s_application2/presentation/home_screen/binding/home_binding.dart';
import 'package:eric_s_application2/presentation/book_appointment_four_screen/book_appointment_four_screen.dart';
import 'package:eric_s_application2/presentation/book_appointment_four_screen/binding/book_appointment_four_binding.dart';
import 'package:eric_s_application2/presentation/choose_doctor_screen/choose_doctor_screen.dart';
import 'package:eric_s_application2/presentation/choose_doctor_screen/binding/choose_doctor_binding.dart';
import 'package:eric_s_application2/presentation/calendar_one_screen/calendar_one_screen.dart';
import 'package:eric_s_application2/presentation/calendar_one_screen/binding/calendar_one_binding.dart';
import 'package:eric_s_application2/presentation/book_appointment_three_screen/book_appointment_three_screen.dart';
import 'package:eric_s_application2/presentation/book_appointment_three_screen/binding/book_appointment_three_binding.dart';
import 'package:eric_s_application2/presentation/book_appointment_one_screen/book_appointment_one_screen.dart';
import 'package:eric_s_application2/presentation/book_appointment_one_screen/binding/book_appointment_one_binding.dart';
import 'package:eric_s_application2/presentation/book_appointment_two_screen/book_appointment_two_screen.dart';
import 'package:eric_s_application2/presentation/book_appointment_two_screen/binding/book_appointment_two_binding.dart';
import 'package:eric_s_application2/presentation/book_appointment_screen/book_appointment_screen.dart';
import 'package:eric_s_application2/presentation/book_appointment_screen/binding/book_appointment_binding.dart';
import 'package:eric_s_application2/presentation/pop_up_screen/pop_up_screen.dart';
import 'package:eric_s_application2/presentation/pop_up_screen/binding/pop_up_binding.dart';
import 'package:eric_s_application2/presentation/ai_chat_screen/ai_chat_screen.dart';
import 'package:eric_s_application2/presentation/ai_chat_screen/binding/ai_chat_binding.dart';
import 'package:eric_s_application2/presentation/search_container1_screen/search_container1_screen.dart';
import 'package:eric_s_application2/presentation/search_container1_screen/binding/search_container1_binding.dart';
import 'package:eric_s_application2/presentation/calendar_screen/calendar_screen.dart';
import 'package:eric_s_application2/presentation/calendar_screen/binding/calendar_binding.dart';
import 'package:eric_s_application2/presentation/calendar_two_screen/calendar_two_screen.dart';
import 'package:eric_s_application2/presentation/calendar_two_screen/binding/calendar_two_binding.dart';
import 'package:eric_s_application2/presentation/messages_screen/messages_screen.dart';
import 'package:eric_s_application2/presentation/messages_screen/binding/messages_binding.dart';
import 'package:eric_s_application2/presentation/profile_screen/profile_screen.dart';
import 'package:eric_s_application2/presentation/profile_screen/binding/profile_binding.dart';
import 'package:eric_s_application2/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:eric_s_application2/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String homescreenScreen = '/homescreen_screen';

  static const String onboardingOneScreen = '/onboarding_one_screen';

  static const String loginScreen = '/login_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String signUpTwoPage = '/sign_up_two_page';

  static const String signUpTwoTabContainerScreen =
      '/sign_up_two_tab_container_screen';

  static const String signUpOneScreen = '/sign_up_one_screen';

  static const String homeScreen = '/home_screen';

  static const String bookAppointmentFourScreen =
      '/book_appointment_four_screen';

  static const String chooseDoctorScreen = '/choose_doctor_screen';

  static const String calendarOneScreen = '/calendar_one_screen';

  static const String bookAppointmentThreeScreen =
      '/book_appointment_three_screen';

  static const String bookAppointmentOneScreen = '/book_appointment_one_screen';

  static const String bookAppointmentTwoScreen = '/book_appointment_two_screen';

  static const String bookAppointmentScreen = '/book_appointment_screen';

  static const String popUpScreen = '/pop_up_screen';

  static const String aiChatScreen = '/ai_chat_screen';

  static const String searchContainerPage = '/search_container_page';

  static const String searchContainer1Screen = '/search_container1_screen';

  static const String calendarScreen = '/calendar_screen';

  static const String calendarTwoScreen = '/calendar_two_screen';

  static const String messagesScreen = '/messages_screen';

  static const String profileScreen = '/profile_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: homescreenScreen,
      page: () => HomescreenScreen(),
      bindings: [
        HomescreenBinding(),
      ],
    ),
    GetPage(
      name: onboardingOneScreen,
      page: () => OnboardingOneScreen(),
      bindings: [
        OnboardingOneBinding(),
      ],
    ),
    GetPage(
      name: loginScreen,
      page: () => LoginScreen(),
      bindings: [
        LoginBinding(),
      ],
    ),
    GetPage(
      name: signUpScreen,
      page: () => SignUpScreen(),
      bindings: [
        SignUpBinding(),
      ],
    ),
    GetPage(
      name: signUpTwoTabContainerScreen,
      page: () => SignUpTwoTabContainerScreen(),
      bindings: [
        SignUpTwoTabContainerBinding(),
      ],
    ),
    GetPage(
      name: signUpOneScreen,
      page: () => SignUpOneScreen(),
      bindings: [
        SignUpOneBinding(),
      ],
    ),
    GetPage(
      name: homeScreen,
      page: () => HomeScreen(),
      bindings: [
        HomeBinding(),
      ],
    ),
    GetPage(
      name: bookAppointmentFourScreen,
      page: () => BookAppointmentFourScreen(),
      bindings: [
        BookAppointmentFourBinding(),
      ],
    ),
    GetPage(
      name: chooseDoctorScreen,
      page: () => ChooseDoctorScreen(),
      bindings: [
        ChooseDoctorBinding(),
      ],
    ),
    GetPage(
      name: calendarOneScreen,
      page: () => CalendarOneScreen(),
      bindings: [
        CalendarOneBinding(),
      ],
    ),
    GetPage(
      name: bookAppointmentThreeScreen,
      page: () => BookAppointmentThreeScreen(),
      bindings: [
        BookAppointmentThreeBinding(),
      ],
    ),
    GetPage(
      name: bookAppointmentOneScreen,
      page: () => BookAppointmentOneScreen(),
      bindings: [
        BookAppointmentOneBinding(),
      ],
    ),
    GetPage(
      name: bookAppointmentTwoScreen,
      page: () => BookAppointmentTwoScreen(),
      bindings: [
        BookAppointmentTwoBinding(),
      ],
    ),
    GetPage(
      name: bookAppointmentScreen,
      page: () => BookAppointmentScreen(),
      bindings: [
        BookAppointmentBinding(),
      ],
    ),
    GetPage(
      name: popUpScreen,
      page: () => PopUpScreen(),
      bindings: [
        PopUpBinding(),
      ],
    ),
    GetPage(
      name: aiChatScreen,
      page: () => AiChatScreen(),
      bindings: [
        AiChatBinding(),
      ],
    ),
    GetPage(
      name: searchContainer1Screen,
      page: () => SearchContainer1Screen(),
      bindings: [
        SearchContainer1Binding(),
      ],
    ),
    GetPage(
      name: calendarScreen,
      page: () => CalendarScreen(),
      bindings: [
        CalendarBinding(),
      ],
    ),
    GetPage(
      name: calendarTwoScreen,
      page: () => CalendarTwoScreen(),
      bindings: [
        CalendarTwoBinding(),
      ],
    ),
    GetPage(
      name: messagesScreen,
      page: () => MessagesScreen(),
      bindings: [
        MessagesBinding(),
      ],
    ),
    GetPage(
      name: profileScreen,
      page: () => ProfileScreen(),
      bindings: [
        ProfileBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => HomescreenScreen(),
      bindings: [
        HomescreenBinding(),
      ],
    )
  ];
}
