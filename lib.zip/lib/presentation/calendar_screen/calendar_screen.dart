import 'controller/calendar_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/search_container_page/search_container_page.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarScreen extends GetWidget<CalendarController> {
  const CalendarScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  SizedBox(height: 24.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 15.h),
                              child: Column(children: [
                                _buildFrame2(),
                                SizedBox(height: 5.v),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                        "msg_see_all_your_appointments".tr,
                                        style: theme.textTheme.titleMedium)),
                                SizedBox(height: 26.v),
                                _buildCALENDAR(),
                                SizedBox(height: 34.v),
                                _buildFrame3(),
                                SizedBox(height: 37.v),
                                _buildFrame4(),
                                SizedBox(height: 26.v),
                                _buildFrame5(),
                                SizedBox(height: 8.v),
                                Divider(color: theme.colorScheme.primary),
                                SizedBox(height: 25.v),
                                _buildFrame6(),
                                SizedBox(height: 36.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.h),
                                    child: _buildFrame1(time: "lbl_2_pm".tr)),
                                SizedBox(height: 37.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.h),
                                    child: _buildFrame(time: "lbl_4_pm".tr)),
                                SizedBox(height: 37.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.h),
                                    child: _buildFrame(time: "lbl_5_pm".tr)),
                                SizedBox(height: 36.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.h),
                                    child: _buildFrame1(time: "lbl_6_pm".tr)),
                                SizedBox(height: 36.v),
                                Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.h),
                                    child: _buildFrame1(time: "lbl_7_pm".tr))
                              ]))))
                ])),
            bottomNavigationBar: _buildBottomBar()));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              centerTitle: true, title: AppbarTitle(text: "lbl_calendar".tr))
        ]));
  }

  /// Section Widget
  Widget _buildFrame2() {
    return Padding(
        padding: EdgeInsets.only(right: 1.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(top: 8.v, bottom: 6.v),
              child: Text("lbl_appointments".tr,
                  style: CustomTextStyles.titleMediumGray900)),
          Container(
              padding: EdgeInsets.symmetric(horizontal: 13.h, vertical: 9.v),
              decoration: AppDecoration.outlinePrimaryContainer2
                  .copyWith(borderRadius: BorderRadiusStyle.circleBorder22),
              child:
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                CustomImageView(
                    imagePath: ImageConstant.imgToc,
                    height: 20.adaptSize,
                    width: 20.adaptSize,
                    onTap: () {
                      onTapImgToc();
                    }),
                Padding(
                    padding: EdgeInsets.only(left: 20.h),
                    child: SizedBox(
                        height: 20.v,
                        child: VerticalDivider(
                            width: 1.h,
                            thickness: 1.v,
                            color: theme.colorScheme.primaryContainer))),
                CustomImageView(
                    imagePath: ImageConstant.imgCalendarMonthPrimary,
                    height: 20.adaptSize,
                    width: 20.adaptSize,
                    margin: EdgeInsets.only(left: 20.h))
              ]))
        ]));
  }

  /// Section Widget
  Widget _buildCALENDAR() {
    return Obx(() => SizedBox(
        height: 127.v,
        width: 358.h,
        child: TableCalendar(
            locale: 'en_US',
            firstDay: DateTime(DateTime.now().year - 5),
            lastDay: DateTime(DateTime.now().year + 5),
            calendarFormat: CalendarFormat.month,
            rangeSelectionMode: controller.rangeSelectionMode.value,
            startingDayOfWeek: StartingDayOfWeek.sunday,
            headerStyle:
                HeaderStyle(formatButtonVisible: false, titleCentered: true),
            calendarStyle: CalendarStyle(
                outsideDaysVisible: false,
                isTodayHighlighted: true,
                todayTextStyle: TextStyle(
                    color: theme.colorScheme.onPrimary.withOpacity(1),
                    fontFamily: 'GT Walsheim Pro',
                    fontWeight: FontWeight.w700),
                todayDecoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(17.h))),
            daysOfWeekStyle: DaysOfWeekStyle(
                weekdayStyle: TextStyle(
                    color: appTheme.blueGray500,
                    fontFamily: 'GT Walsheim Pro',
                    fontWeight: FontWeight.w700)),
            headerVisible: false,
            rowHeight: 34.adaptSize,
            focusedDay: controller.focusedDay.value,
            rangeStartDay: controller.rangeStart,
            rangeEndDay: controller.rangeEnd,
            onDaySelected: (selectedDay, focusedDay) {
              if (!isSameDay(controller.selectedDay, selectedDay)) {
                controller.focusedDay.value = focusedDay;
                controller.selectedDay = selectedDay;
                controller.rangeSelectionMode.value =
                    RangeSelectionMode.toggledOn;
              }
            },
            onRangeSelected: (start, end, focusedDay) {
              controller.focusedDay.value = focusedDay;
              controller.rangeEnd = end;
              controller.rangeStart = start;
              controller.rangeSelectionMode.value =
                  RangeSelectionMode.toggledOn;
            },
            onPageChanged: (focusedDay) {
              controller.focusedDay.value = focusedDay;
            })));
  }

  /// Section Widget
  Widget _buildFrame3() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text("lbl_10_am".tr, style: theme.textTheme.titleSmall),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(top: 8.v, bottom: 9.v),
                  child: Divider(indent: 10.h)))
        ]));
  }

  /// Section Widget
  Widget _buildFrame4() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text("lbl_11_am".tr, style: theme.textTheme.titleSmall),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(top: 8.v, bottom: 9.v),
                  child: Divider(indent: 10.h)))
        ]));
  }

  /// Section Widget
  Widget _buildFrame5() {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Padding(
          padding: EdgeInsets.symmetric(vertical: 11.v),
          child:
              Text("lbl_12_pm".tr, style: CustomTextStyles.titleSmallPrimary)),
      Container(
          height: 40.v,
          width: 309.h,
          margin: EdgeInsets.only(left: 10.h),
          child: Stack(alignment: Alignment.centerRight, children: [
            Align(
                alignment: Alignment.center,
                child: Container(
                    height: 40.v,
                    width: 308.h,
                    decoration: BoxDecoration(
                        color: appTheme.lightBlue5001,
                        borderRadius:
                            BorderRadius.horizontal(left: Radius.circular(6.h)),
                        border: Border.all(
                            color: appTheme.lightBlue200, width: 1.h)),
                    child: ClipRRect(
                        borderRadius:
                            BorderRadius.horizontal(left: Radius.circular(6.h)),
                        child: LinearProgressIndicator(
                            value: 0.02,
                            backgroundColor: appTheme.lightBlue5001,
                            valueColor: AlwaysStoppedAnimation<Color>(
                                theme.colorScheme.primary))))),
            Align(
                alignment: Alignment.centerRight,
                child: Text("msg_appointment_with".tr,
                    style: CustomTextStyles.titleMediumPrimary))
          ]))
    ]);
  }

  /// Section Widget
  Widget _buildFrame6() {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text("lbl_1_pm".tr, style: theme.textTheme.titleSmall),
          Expanded(
              child: Padding(
                  padding: EdgeInsets.only(top: 8.v, bottom: 9.v),
                  child: Divider(indent: 10.h)))
        ]));
  }

  /// Section Widget
  Widget _buildBottomBar() {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Get.toNamed(getCurrentRoute(type), id: 1);
    });
  }

  /// Common widget
  Widget _buildFrame({required String time}) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(time,
          style: theme.textTheme.titleSmall!
              .copyWith(color: appTheme.blueGray500)),
      Expanded(
          child: Padding(
              padding: EdgeInsets.only(top: 8.v, bottom: 9.v),
              child: Divider(indent: 10.h)))
    ]);
  }

  /// Common widget
  Widget _buildFrame1({required String time}) {
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Text(time,
          style: theme.textTheme.titleSmall!
              .copyWith(color: appTheme.blueGray500)),
      Expanded(
          child: Padding(
              padding: EdgeInsets.only(top: 8.v, bottom: 9.v),
              child: Divider(indent: 10.h)))
    ]);
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.searchContainerPage;
      case BottomBarEnum.Search:
        return "/";
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Message:
        return "/";
      case BottomBarEnum.Profile:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.searchContainerPage:
        return SearchContainerPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the calendarTwoScreen when the action is triggered.
  onTapImgToc() {
    Get.toNamed(
      AppRoutes.calendarTwoScreen,
    );
  }
}
