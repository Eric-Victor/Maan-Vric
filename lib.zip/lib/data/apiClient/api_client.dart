import 'package:eric_s_application2/core/app_export.dart';

class ApiClient extends GetConnect {}
