import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/calendar_screen/models/calendar_model.dart';
import 'package:table_calendar/table_calendar.dart';

/// A controller class for the CalendarScreen.
///
/// This class manages the state of the CalendarScreen, including the
/// current calendarModelObj
class CalendarController extends GetxController {
  Rx<CalendarModel> calendarModelObj = CalendarModel().obs;

  DateTime? rangeStart;

  DateTime? rangeEnd;

  DateTime? selectedDay;

  Rx<DateTime> focusedDay = DateTime.now().obs;

  Rx<RangeSelectionMode> rangeSelectionMode = RangeSelectionMode.toggledOn.obs;
}
