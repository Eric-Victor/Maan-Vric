import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/presentation/pop_up_screen/models/pop_up_model.dart';

/// A controller class for the PopUpScreen.
///
/// This class manages the state of the PopUpScreen, including the
/// current popUpModelObj
class PopUpController extends GetxController {
  Rx<PopUpModel> popUpModelObj = PopUpModel().obs;
}
