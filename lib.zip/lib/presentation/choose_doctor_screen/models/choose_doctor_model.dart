import 'package:eric_s_application2/data/models/selectionPopupModel/selection_popup_model.dart';
import 'doctorscloseby_item_model.dart';
import '../../../core/app_export.dart';

/// This class defines the variables used in the [choose_doctor_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ChooseDoctorModel {
  Rx<List<SelectionPopupModel>> dropdownItemList = Rx([
    SelectionPopupModel(
      id: 1,
      title: "Item One",
      isSelected: true,
    ),
    SelectionPopupModel(
      id: 2,
      title: "Item Two",
    ),
    SelectionPopupModel(
      id: 3,
      title: "Item Three",
    )
  ]);

  Rx<List<SelectionPopupModel>> dropdownItemList1 = Rx([
    SelectionPopupModel(
      id: 1,
      title: "Item One",
      isSelected: true,
    ),
    SelectionPopupModel(
      id: 2,
      title: "Item Two",
    ),
    SelectionPopupModel(
      id: 3,
      title: "Item Three",
    )
  ]);

  Rx<List<SelectionPopupModel>> dropdownItemList2 = Rx([
    SelectionPopupModel(
      id: 1,
      title: "Item One",
      isSelected: true,
    ),
    SelectionPopupModel(
      id: 2,
      title: "Item Two",
    ),
    SelectionPopupModel(
      id: 3,
      title: "Item Three",
    )
  ]);

  Rx<List<DoctorsclosebyItemModel>> doctorsclosebyItemList = Rx([
    DoctorsclosebyItemModel(groupBy: "Doctors close-by".obs),
    DoctorsclosebyItemModel(groupBy: "Doctors close-by".obs),
    DoctorsclosebyItemModel(groupBy: "Doctors close-by".obs),
    DoctorsclosebyItemModel(groupBy: "Available doctors".obs),
    DoctorsclosebyItemModel(groupBy: "Available doctors".obs),
    DoctorsclosebyItemModel(groupBy: "Available doctors".obs),
    DoctorsclosebyItemModel(groupBy: "Available doctors".obs),
    DoctorsclosebyItemModel(groupBy: "Available doctors".obs)
  ]);
}
