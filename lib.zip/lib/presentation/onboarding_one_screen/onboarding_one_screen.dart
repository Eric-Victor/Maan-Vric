import 'controller/onboarding_one_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnboardingOneScreen extends GetWidget<OnboardingOneController> {
  const OnboardingOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: 797.v,
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 55.v),
                child: Stack(alignment: Alignment.center, children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgLinePattern,
                      height: 200.adaptSize,
                      width: 200.adaptSize,
                      radius: BorderRadius.circular(100.h),
                      alignment: Alignment.topCenter),
                  Align(
                      alignment: Alignment.center,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        CustomImageView(
                            imagePath: ImageConstant.imgOpenPeepsBust,
                            height: 246.v,
                            width: 273.h),
                        SizedBox(height: 64.v),
                        SizedBox(
                            height: 24.v,
                            child: AnimatedSmoothIndicator(
                                activeIndex: 0,
                                count: 2,
                                effect: ScrollingDotsEffect(
                                    activeDotColor: Color(0X1212121D),
                                    dotHeight: 24.v))),
                        SizedBox(height: 35.v),
                        Container(
                            width: 332.h,
                            margin: EdgeInsets.symmetric(horizontal: 12.h),
                            child: Text("msg_video_consult_top".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.titleLarge!
                                    .copyWith(height: 1.50))),
                        SizedBox(height: 13.v),
                        SizedBox(
                            width: 358.h,
                            child: Text("msg_these_are_specialists".tr,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                                style: theme.textTheme.titleMedium!
                                    .copyWith(height: 1.50))),
                        SizedBox(height: 30.v),
                        CustomOutlinedButton(
                            text: "lbl_sign_in".tr,
                            onPressed: () {
                              onTapSignIn();
                            }),
                        SizedBox(height: 12.v),
                        CustomOutlinedButton(
                            text: "msg_create_an_account".tr,
                            buttonStyle:
                                CustomButtonStyles.outlinePrimaryContainer,
                            buttonTextStyle:
                                CustomTextStyles.titleMediumGray900_1,
                            onPressed: () {
                              onTapCreateAnAccount();
                            })
                      ])),
                  CustomImageView(
                      imagePath: ImageConstant.imgGroup1,
                      height: 295.v,
                      width: 265.h,
                      alignment: Alignment.topCenter,
                      margin: EdgeInsets.only(top: 9.v))
                ]))));
  }

  /// Navigates to the loginScreen when the action is triggered.
  onTapSignIn() {
    Get.toNamed(
      AppRoutes.loginScreen,
    );
  }

  /// Navigates to the signUpScreen when the action is triggered.
  onTapCreateAnAccount() {
    Get.toNamed(
      AppRoutes.signUpScreen,
    );
  }
}
