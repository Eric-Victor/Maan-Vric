import 'controller/book_appointment_one_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title.dart';
import 'package:eric_s_application2/widgets/app_bar/appbar_title_button_one.dart';
import 'package:eric_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:eric_s_application2/widgets/custom_radio_button.dart';
import 'package:flutter/material.dart';

class BookAppointmentOneScreen extends GetWidget<BookAppointmentOneController> {
  const BookAppointmentOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildTopNavigation(),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Container(
                              height: 776.v,
                              width: double.maxFinite,
                              margin: EdgeInsets.only(bottom: 5.v),
                              padding: EdgeInsets.symmetric(vertical: 25.v),
                              decoration: AppDecoration.fillOnPrimary,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Align(
                                        alignment: Alignment.topCenter,
                                        child: Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 16.h),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                      width: 306.h,
                                                      margin: EdgeInsets.only(
                                                          right: 50.h),
                                                      child: Text(
                                                          "msg_are_you_allergic"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: CustomTextStyles
                                                              .titleMediumGray900
                                                              .copyWith(
                                                                  height:
                                                                      1.56))),
                                                  SizedBox(height: 7.v),
                                                  Container(
                                                      width: 351.h,
                                                      margin: EdgeInsets.only(
                                                          right: 5.h),
                                                      child: Text(
                                                          "msg_see_list_the_medications"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 9.v),
                                                  Text(
                                                      "msg_examples_amoxicillin"
                                                          .tr,
                                                      style: theme.textTheme
                                                          .titleMedium),
                                                  SizedBox(height: 8.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 117.h),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            _buildInputField(),
                                                            _buildLabel()
                                                          ])),
                                                  SizedBox(height: 42.v),
                                                  Text(
                                                      "msg_do_you_have_any2".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumGray900),
                                                  SizedBox(height: 8.v),
                                                  Container(
                                                      width: 307.h,
                                                      margin: EdgeInsets.only(
                                                          right: 48.h),
                                                      child: Text(
                                                          "msg_not_sure_choose"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 9.v),
                                                  Text(
                                                      "msg_examples_high_cholesterol"
                                                          .tr,
                                                      style: theme.textTheme
                                                          .titleMedium),
                                                  SizedBox(height: 8.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 117.h),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            _buildInputField(),
                                                            _buildLabel1()
                                                          ])),
                                                  SizedBox(height: 42.v),
                                                  Text(
                                                      "msg_have_you_had_any".tr,
                                                      style: CustomTextStyles
                                                          .titleMediumGray900),
                                                  SizedBox(height: 8.v),
                                                  Container(
                                                      width: 319.h,
                                                      margin: EdgeInsets.only(
                                                          right: 36.h),
                                                      child: Text(
                                                          "msg_examples_appendectomy"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 7.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 117.h),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            _buildInputField(),
                                                            _buildLabel2()
                                                          ])),
                                                  SizedBox(height: 41.v),
                                                  Container(
                                                      width: 303.h,
                                                      margin: EdgeInsets.only(
                                                          right: 53.h),
                                                      child: Text(
                                                          "msg_has_anyone_in_your"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: CustomTextStyles
                                                              .titleMediumGray900
                                                              .copyWith(
                                                                  height:
                                                                      1.56))),
                                                  SizedBox(height: 7.v),
                                                  Container(
                                                      width: 315.h,
                                                      margin: EdgeInsets.only(
                                                          right: 40.h),
                                                      child: Text(
                                                          "msg_please_only_include"
                                                              .tr,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style: theme.textTheme
                                                              .titleMedium!
                                                              .copyWith(
                                                                  height:
                                                                      1.50))),
                                                  SizedBox(height: 6.v),
                                                  Padding(
                                                      padding: EdgeInsets.only(
                                                          right: 117.h),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            _buildInputField(),
                                                            Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                children: [
                                                                  CustomImageView(
                                                                      imagePath:
                                                                          ImageConstant
                                                                              .imgRadioCheckboxGray300,
                                                                      height:
                                                                          24.v,
                                                                      width:
                                                                          30.h),
                                                                  Padding(
                                                                      padding: EdgeInsets.only(
                                                                          left: 4
                                                                              .h),
                                                                      child: Text(
                                                                          "lbl_no"
                                                                              .tr,
                                                                          style:
                                                                              CustomTextStyles.titleMediumBluegray900))
                                                                ])
                                                          ]))
                                                ]))),
                                    _buildInputField5()
                                  ]))))
                ]))));
  }

  /// Section Widget
  Widget _buildTopNavigation() {
    return Container(
        padding: EdgeInsets.symmetric(vertical: 14.v),
        decoration: AppDecoration.outlineBlack,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(height: 8.v),
          CustomAppBar(
              title: Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Row(children: [
                    AppbarTitleButtonOne(
                        margin: EdgeInsets.symmetric(vertical: 1.v),
                        onTap: () {
                          onTapBack();
                        }),
                    AppbarTitle(
                        text: "lbl_health_profile".tr,
                        margin: EdgeInsets.only(left: 52.h))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildLabel() {
    return Obx(() => CustomRadioButton(
        text: "lbl_no".tr,
        value: "lbl_no".tr,
        groupValue: controller.radioGroup.value,
        padding: EdgeInsets.symmetric(vertical: 1.v),
        onChange: (value) {
          controller.radioGroup.value = value;
        }));
  }

  /// Section Widget
  Widget _buildLabel1() {
    return Obx(() => CustomRadioButton(
        text: "lbl_no".tr,
        value: "lbl_no".tr,
        groupValue: controller.radioGroup1.value,
        padding: EdgeInsets.symmetric(vertical: 1.v),
        onChange: (value) {
          controller.radioGroup1.value = value;
        }));
  }

  /// Section Widget
  Widget _buildLabel2() {
    return Obx(() => CustomRadioButton(
        text: "lbl_no".tr,
        value: "lbl_no".tr,
        groupValue: controller.radioGroup2.value,
        padding: EdgeInsets.symmetric(vertical: 1.v),
        onChange: (value) {
          controller.radioGroup2.value = value;
        }));
  }

  /// Section Widget
  Widget _buildInputField5() {
    return Align(
        alignment: Alignment.bottomCenter,
        child: Container(
            margin: EdgeInsets.only(bottom: 53.v),
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            decoration: AppDecoration.outlineBlack90001,
            child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SizedBox(height: 21.v),
                  GestureDetector(
                      onTap: () {
                        onTapButtonBase();
                      },
                      child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 72.h),
                          decoration: AppDecoration.outlinePrimary.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder8),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Padding(
                                    padding: EdgeInsets.only(top: 12.v),
                                    child: Text("lbl_next".tr,
                                        style: CustomTextStyles
                                            .titleMediumOnPrimary)),
                                Container(
                                    height: 1.v,
                                    width: 20.h,
                                    margin:
                                        EdgeInsets.only(top: 23.v, bottom: 3.v),
                                    decoration: BoxDecoration(
                                        color: theme
                                            .colorScheme.primaryContainer)),
                                Padding(
                                    padding: EdgeInsets.only(top: 12.v),
                                    child: Text("lbl_review_profile".tr,
                                        style: CustomTextStyles
                                            .titleMediumPrimaryContainer)),
                                CustomImageView(
                                    imagePath: ImageConstant.imgArrowright,
                                    height: 15.v,
                                    width: 24.h,
                                    margin: EdgeInsets.only(top: 12.v))
                              ])))
                ])));
  }

  /// Common widget
  Widget _buildInputField() {
    return SizedBox(
        width: 60.h,
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          CustomImageView(
              imagePath: ImageConstant.imgRadioCheckboxGray300,
              height: 24.v,
              width: 30.h),
          Text("lbl_yes".tr, style: CustomTextStyles.titleMediumBluegray900)
        ]));
  }

  /// Navigates to the bookAppointmentThreeScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.bookAppointmentThreeScreen,
    );
  }

  /// Navigates to the bookAppointmentTwoScreen when the action is triggered.
  onTapButtonBase() {
    Get.toNamed(
      AppRoutes.bookAppointmentTwoScreen,
    );
  }
}
