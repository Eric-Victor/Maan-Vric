import '../../../core/app_export.dart';
import 'searchcontainer_item_model.dart';

/// This class defines the variables used in the [search_container_page],
/// and is typically used to hold data that is passed between different parts of the application.
class SearchContainerModel {
  Rx<List<SearchcontainerItemModel>> searchcontainerItemList = Rx([
    SearchcontainerItemModel(
        event: ImageConstant.imgEvent.obs,
        bookAnAppointment: "Book an Appointment".obs,
        findADoctor: "Find a Doctor".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgOtherHouses.obs,
        bookAnAppointment: "Request a Physical Consultation".obs,
        findADoctor: "Talk to a Specialist".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgLocalHospital.obs,
        bookAnAppointment: "Find a Health Center".obs,
        findADoctor: "Find the Nearest Clinic".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgLocalPharmacy.obs,
        bookAnAppointment: "Locate a Pharmacy".obs,
        findADoctor: "Purchase Medications".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgScience.obs,
        bookAnAppointment: "Order a Lab Test".obs,
        findADoctor: "Get Tested at Home".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgAirportShuttle.obs,
        bookAnAppointment: "Emergency Situation".obs,
        findADoctor: "Request an Ambulance".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgQuestionAnswer.obs,
        bookAnAppointment: "Health Q&A".obs,
        findADoctor: "Speak to a Doctor".obs),
    SearchcontainerItemModel(
        event: ImageConstant.imgVolunteerActivism.obs,
        bookAnAppointment: "Symptoms Assessments".obs,
        findADoctor: "Speak to a Physician.".obs)
  ]);
}
