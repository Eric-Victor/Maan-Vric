import 'controller/sign_up_two_controller.dart';
import 'models/sign_up_two_model.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class SignUpTwoPage extends StatelessWidget {
  SignUpTwoPage({Key? key}) : super(key: key);

  SignUpTwoController controller =
      Get.put(SignUpTwoController(SignUpTwoModel().obs));

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false, body: _buildScrollView()));
  }

  /// Section Widget
  Widget _buildScrollView() {
    return SingleChildScrollView(
        child: Column(children: [
      SizedBox(height: 19.v),
      Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: Column(children: [
            Align(
                alignment: Alignment.centerLeft,
                child: Text("lbl_aadhar_number".tr,
                    style: CustomTextStyles.titleSmallPoppinsBluegray80001)),
            SizedBox(height: 5.v),
            CustomTextFormField(
                controller: controller.inputController,
                textInputAction: TextInputAction.done),
            SizedBox(height: 12.v),
            CustomOutlinedButton(text: "lbl_continue".tr),
            SizedBox(height: 18.v),
            GestureDetector(
                onTap: () {
                  onTapTxtByprovidingyourmobil();
                },
                child: Container(
                    width: 329.h,
                    margin: EdgeInsets.symmetric(horizontal: 14.h),
                    child: Text("msg_by_providing_your".tr,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: theme.textTheme.titleMedium!
                            .copyWith(height: 1.50))))
          ]))
    ]));
  }

  /// Navigates to the loginScreen when the action is triggered.
  onTapTxtByprovidingyourmobil() {
    Get.toNamed(
      AppRoutes.loginScreen,
    );
  }
}
