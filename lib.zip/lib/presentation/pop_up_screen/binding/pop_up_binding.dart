import '../controller/pop_up_controller.dart';
import 'package:get/get.dart';

/// A binding class for the PopUpScreen.
///
/// This class ensures that the PopUpController is created when the
/// PopUpScreen is first loaded.
class PopUpBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => PopUpController());
  }
}
