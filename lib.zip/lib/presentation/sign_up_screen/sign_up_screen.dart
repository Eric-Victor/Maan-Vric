import 'controller/sign_up_controller.dart';
import 'package:eric_s_application2/core/app_export.dart';
import 'package:eric_s_application2/core/utils/validation_functions.dart';
import 'package:eric_s_application2/widgets/custom_outlined_button.dart';
import 'package:eric_s_application2/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class SignUpScreen extends GetWidget<SignUpController> {
  SignUpScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(
              horizontal: 16.h,
              vertical: 56.v,
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "lbl_maanvric".tr,
                      style: CustomTextStyles.headlineSmallPrimary_1,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgBeatingheart,
                      height: 31.v,
                      width: 33.h,
                    ),
                  ],
                ),
                SizedBox(height: 21.v),
                Text(
                  "msg_create_an_account".tr,
                  style: theme.textTheme.headlineSmall,
                ),
                SizedBox(height: 11.v),
                Container(
                  width: 302.h,
                  margin: EdgeInsets.only(
                    left: 28.h,
                    right: 27.h,
                  ),
                  child: Text(
                    "msg_let_s_get_you_started".tr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: theme.textTheme.titleMedium!.copyWith(
                      height: 1.50,
                    ),
                  ),
                ),
                SizedBox(height: 31.v),
                _buildInputWithLabel(),
                SizedBox(height: 20.v),
                _buildInputFieldBase(),
                SizedBox(height: 22.v),
                CustomOutlinedButton(
                  text: "lbl_continue".tr,
                ),
                SizedBox(height: 40.v),
                Container(
                  width: 342.h,
                  margin: EdgeInsets.symmetric(horizontal: 8.h),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "msg_by_clicking_continue2".tr,
                          style: theme.textTheme.titleMedium,
                        ),
                        TextSpan(
                          text: "lbl_privacy_policy".tr,
                          style: CustomTextStyles.titleMediumPrimary_1,
                        ),
                        TextSpan(
                          text: "lbl_and".tr,
                          style: theme.textTheme.titleMedium,
                        ),
                        TextSpan(
                          text: "msg_terms_of_service".tr,
                          style: CustomTextStyles.titleMediumPrimary_1,
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 48.v),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "msg_already_have_an2".tr,
                        style: theme.textTheme.titleMedium,
                      ),
                      TextSpan(
                        text: "lbl_sign_in".tr,
                        style: CustomTextStyles.titleMediumPrimary_1,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
                SizedBox(height: 5.v),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildInputWithLabel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "lbl_email".tr,
          style: CustomTextStyles.titleSmallBluegray80001,
        ),
        SizedBox(height: 6.v),
        CustomTextFormField(
          controller: controller.emailController,
          hintText: "msg_example_email_com".tr,
          textInputType: TextInputType.emailAddress,
          prefix: Container(
            margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
            child: CustomImageView(
              imagePath: ImageConstant.imgMail,
              height: 20.adaptSize,
              width: 20.adaptSize,
            ),
          ),
          prefixConstraints: BoxConstraints(
            maxHeight: 56.v,
          ),
          validator: (value) {
            if (value == null || (!isValidEmail(value, isRequired: true))) {
              return "err_msg_please_enter_valid_email".tr;
            }
            return null;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildInputFieldBase() {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "lbl_password".tr,
            style: CustomTextStyles.titleSmallBluegray80001,
          ),
        ),
        SizedBox(height: 6.v),
        Obx(
          () => CustomTextFormField(
            controller: controller.passwordController,
            hintText: "msg_8_characters_minimum".tr,
            textInputAction: TextInputAction.done,
            textInputType: TextInputType.visiblePassword,
            prefix: Container(
              margin: EdgeInsets.fromLTRB(14.h, 18.v, 8.h, 18.v),
              child: CustomImageView(
                imagePath: ImageConstant.imgUnlock,
                height: 20.adaptSize,
                width: 20.adaptSize,
              ),
            ),
            prefixConstraints: BoxConstraints(
              maxHeight: 56.v,
            ),
            suffix: InkWell(
              onTap: () {
                controller.isShowPassword.value =
                    !controller.isShowPassword.value;
              },
              child: Container(
                margin: EdgeInsets.fromLTRB(30.h, 18.v, 14.h, 18.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgEyeGray900,
                  height: 20.adaptSize,
                  width: 20.adaptSize,
                ),
              ),
            ),
            suffixConstraints: BoxConstraints(
              maxHeight: 56.v,
            ),
            validator: (value) {
              if (value == null ||
                  (!isValidPassword(value, isRequired: true))) {
                return "err_msg_please_enter_valid_password".tr;
              }
              return null;
            },
            obscureText: controller.isShowPassword.value,
            contentPadding: EdgeInsets.symmetric(vertical: 17.v),
          ),
        ),
        SizedBox(height: 8.v),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "msg_password_strength".tr,
              style: theme.textTheme.titleSmall,
            ),
            CustomImageView(
              imagePath: ImageConstant.imgBar,
              height: 8.v,
              width: 217.h,
              margin: EdgeInsets.only(
                top: 3.v,
                bottom: 7.v,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
