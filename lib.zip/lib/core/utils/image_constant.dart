class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Onboarding One images
  static String imgLinePattern = '$imagePath/img_line_pattern.svg';

  static String imgOpenPeepsBust = '$imagePath/img_open_peeps_bust.png';

  static String imgGroup1 = '$imagePath/img_group_1.svg';

  // Login images
  static String imgEye = '$imagePath/img_eye.svg';

  static String imgCheckbox = '$imagePath/img_checkbox.svg';

  // Sign Up images
  static String imgEyeGray900 = '$imagePath/img_eye_gray_900.svg';

  static String imgBar = '$imagePath/img_bar.svg';

  // Sign Up Two - Tab Container images
  static String imgProgressbar = '$imagePath/img_progressbar.svg';

  static String imgAccountcircle = '$imagePath/img_accountcircle.svg';

  static String imgArrowdropup = '$imagePath/img_arrowdropup.svg';

  static String imgArrowdown = '$imagePath/img_arrowdown.svg';

  // Sign Up One images
  static String imgProgressbarBlueGray50 =
      '$imagePath/img_progressbar_blue_gray_50.svg';

  // Home images
  static String imgNotifications = '$imagePath/img_notifications.svg';

  static String imgCalendarMonth = '$imagePath/img_calendar_month.svg';

  static String imgDuo = '$imagePath/img_duo.svg';

  static String imgIcon = '$imagePath/img_icon.svg';

  static String imgVaccines = '$imagePath/img_vaccines.svg';

  static String imgIconrightPrimary = '$imagePath/img_iconright_primary.svg';

  static String imgFemale = '$imagePath/img_female.svg';

  static String imgPhBabyFill = '$imagePath/img_ph_baby_fill.svg';

  static String imgMale = '$imagePath/img_male.svg';

  static String imgElderlyWoman = '$imagePath/img_elderly_woman.svg';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

  // Book appointment Four images
  static String imgImage = '$imagePath/img_image.png';

  static String imgAdd = '$imagePath/img_add.svg';

  static String imgPinDrop = '$imagePath/img_pin_drop.svg';

  static String imgVerified = '$imagePath/img_verified.svg';

  static String imgKingBed = '$imagePath/img_king_bed.svg';

  static String imgMedication = '$imagePath/img_medication.svg';

  static String imgTheaterComedy = '$imagePath/img_theater_comedy.svg';

  static String imgCoronavirus = '$imagePath/img_coronavirus.svg';

  static String imgFemalePink400 = '$imagePath/img_female_pink_400.svg';

  static String imgMalePink400 = '$imagePath/img_male_pink_400.svg';

  static String imgHelpCenter = '$imagePath/img_help_center.svg';

  static String imgEosIconsAiHealingOutlined =
      '$imagePath/img_eos_icons_ai_healing_outlined.svg';

  // Choose doctor images
  static String imgArrowdropdown = '$imagePath/img_arrowdropdown.svg';

  static String imgArrowdropdownBlueGray500 =
      '$imagePath/img_arrowdropdown_blue_gray_500.svg';

  static String imgFilterList = '$imagePath/img_filter_list.svg';

  static String imgRectangle2 = '$imagePath/img_rectangle_2.png';

  static String imgRectangle240x40 = '$imagePath/img_rectangle_2_40x40.png';

  static String imgRectangle21 = '$imagePath/img_rectangle_2_1.png';

  static String imgRectangle22 = '$imagePath/img_rectangle_2_2.png';

  static String imgRectangle23 = '$imagePath/img_rectangle_2_3.png';

  static String imgRectangle24 = '$imagePath/img_rectangle_2_4.png';

  static String imgRectangle25 = '$imagePath/img_rectangle_2_5.png';

  static String imgRectangle26 = '$imagePath/img_rectangle_2_6.png';

  // Calendar One images
  static String imgVuesaxLinearTextalignjustifyright =
      '$imagePath/img_vuesax_linear_textalignjustifyright.svg';

  // Book appointment Three images
  static String imgProgressbarPrimarycontainer =
      '$imagePath/img_progressbar_primarycontainer.svg';

  static String imgIconrightBlueGray70001 =
      '$imagePath/img_iconright_blue_gray_700_01.svg';

  static String imgAddBlueGray80001 = '$imagePath/img_add_blue_gray_800_01.svg';

  // Book appointment images
  static String imgProgressbarGreenA700 =
      '$imagePath/img_progressbar_green_a700.svg';

  static String imgAccountcircleBlueGray500 =
      '$imagePath/img_accountcircle_blue_gray_500.svg';

  static String imgCreditcard = '$imagePath/img_creditcard.svg';

  static String imgHelpIcon = '$imagePath/img_help_icon.svg';

  static String imgPaypal = '$imagePath/img_paypal.svg';

  static String imgSocialIconBlack90001 =
      '$imagePath/img_social_icon_black_900_01.svg';

  // Pop-up images
  static String imgRectangle2120x120 = '$imagePath/img_rectangle_2_120x120.png';

  static String imgVideocam = '$imagePath/img_videocam.svg';

  // AI CHAT images
  static String imgRectangle250x50 = '$imagePath/img_rectangle_2_50x50.png';

  static String imgRectangle230x30 = '$imagePath/img_rectangle_2_30x30.png';

  // Calendar images
  static String imgToc = '$imagePath/img_toc.svg';

  // Calendar Two images
  static String imgTocPrimary = '$imagePath/img_toc_primary.svg';

  static String imgCalendarMonthBlueGray300 =
      '$imagePath/img_calendar_month_blue_gray_300.svg';

  static String imgRectangle29 = '$imagePath/img_rectangle_2_9.png';

  static String imgVideocamOnprimary = '$imagePath/img_videocam_onprimary.svg';

  // Messages images
  static String imgRectangle210 = '$imagePath/img_rectangle_2_10.png';

  static String imgRectangle211 = '$imagePath/img_rectangle_2_11.png';

  // Profile images
  static String imgOpenPeepsAvatar = '$imagePath/img_open_peeps_avatar.png';

  static String imgBorderColor = '$imagePath/img_border_color.svg';

  static String imgHealthiconsPat = '$imagePath/img_healthicons_pat.svg';

  static String imgCreditCardBlue600 =
      '$imagePath/img_credit_card_blue_600.svg';

  static String imgReceipt = '$imagePath/img_receipt.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgNotListedLocation = '$imagePath/img_not_listed_location.svg';

  static String imgLogout = '$imagePath/img_logout.svg';

  static String imgSearchOnprimary = '$imagePath/img_search_onprimary.png';

  // Common images
  static String imgBeatingheart = '$imagePath/img_beatingheart.svg';

  static String imgMail = '$imagePath/img_mail.svg';

  static String imgUnlock = '$imagePath/img_unlock.svg';

  static String imgSocialIcon = '$imagePath/img_social_icon.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgIconright = '$imagePath/img_iconright.svg';

  static String imgEvent = '$imagePath/img_event.svg';

  static String imgNavSearch = '$imagePath/img_nav_search.svg';

  static String imgNavCalendar = '$imagePath/img_nav_calendar.svg';

  static String imgNavMessage = '$imagePath/img_nav_message.svg';

  static String imgSearchBlack90001 = '$imagePath/img_search_black_900_01.png';

  static String imgArrowleft = '$imagePath/img_arrowleft.svg';

  static String imgEmergency = '$imagePath/img_emergency.svg';

  static String imgRectangle27 = '$imagePath/img_rectangle_2_7.png';

  static String imgAddPrimary = '$imagePath/img_add_primary.svg';

  static String imgArrowright = '$imagePath/img_arrowright.svg';

  static String imgRadioCheckbox = '$imagePath/img_radio_checkbox.svg';

  static String imgRadioCheckboxGray300 =
      '$imagePath/img_radio_checkbox_gray_300.svg';

  static String imgArrowLeftPrimary = '$imagePath/img_arrow_left_primary.svg';

  static String imgArrowRightGray800 =
      '$imagePath/img_arrow_right_gray_800.svg';

  static String imgTail = '$imagePath/img_tail.svg';

  static String imgMessageEmoji = '$imagePath/img_message_emoji.png';

  static String imgAddReaction = '$imagePath/img_add_reaction.svg';

  static String imgTailBlueA200 = '$imagePath/img_tail_blue_a200.svg';

  static String imgRectangle28 = '$imagePath/img_rectangle_2_8.png';

  static String imgAlternateEmail = '$imagePath/img_alternate_email.svg';

  static String imgAttachFile = '$imagePath/img_attach_file.svg';

  static String imgImageBlueGray300 = '$imagePath/img_image_blue_gray_300.svg';

  static String imgSentimentSatisfiedAlt =
      '$imagePath/img_sentiment_satisfied_alt.svg';

  static String imgMoreVert = '$imagePath/img_more_vert.svg';

  static String imgSend = '$imagePath/img_send.svg';

  static String imgLocationon = '$imagePath/img_locationon.svg';

  static String imgOtherHouses = '$imagePath/img_other_houses.svg';

  static String imgLocalHospital = '$imagePath/img_local_hospital.svg';

  static String imgLocalPharmacy = '$imagePath/img_local_pharmacy.svg';

  static String imgScience = '$imagePath/img_science.svg';

  static String imgAirportShuttle = '$imagePath/img_airport_shuttle.svg';

  static String imgQuestionAnswer = '$imagePath/img_question_answer.svg';

  static String imgVolunteerActivism = '$imagePath/img_volunteer_activism.svg';

  static String imgNavHomeBlueGray500 =
      '$imagePath/img_nav_home_blue_gray_500.svg';

  static String imgNavSearchPrimary = '$imagePath/img_nav_search_primary.svg';

  static String imgCalendarMonthPrimary =
      '$imagePath/img_calendar_month_primary.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
